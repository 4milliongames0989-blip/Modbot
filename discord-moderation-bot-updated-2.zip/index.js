require('dotenv').config();

// ============================================================
// BOT STATUS — edit these
// ============================================================
// Activity types: Playing | Watching | Listening | Competing | Streaming
const STATUS = {
  type: 'Listening',           // Playing, Watching, Listening, Competing
  text: 'Bot made by 4MG',     // What shows after the type
  // Optional streaming URL (only used if type is Streaming):
  // url: 'https://twitch.tv/yourchannel',
};
// ============================================================

const {
  Client,
  GatewayIntentBits,
  Collection,
  Events,
  ActivityType,
  REST,
  Routes,
} = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./src/config');
const { initStorage } = require('./src/storage');
const { checkExpired } = require('./src/utils/expiry');
const { handleMessage: handleAutomodMessage } = require('./src/commands/automod');

if (!config.token || !config.clientId) {
  console.error('Missing DISCORD_TOKEN or CLIENT_ID in .env');
  process.exit(1);
}

const ACTIVITY_TYPE_MAP = {
  Playing: ActivityType.Playing,
  Watching: ActivityType.Watching,
  Listening: ActivityType.Listening,
  Competing: ActivityType.Competing,
  Streaming: ActivityType.Streaming,
};

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // required for automod
  ],
});

client.commands = new Collection();

// Load commands from disk
const commandsPath = path.join(__dirname, 'src', 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));
const commandJson = [];

function registerCommandModule(command, file = '') {
  if (command.data && command.execute) {
    client.commands.set(command.data.name, {
      data: command.data,
      execute: command.execute,
    });
    commandJson.push(command.data.toJSON());
    console.log(`[Commands] Loaded /${command.data.name}`);
  }
  // Allow one file to register extra top-level commands (e.g. /setautomodlog)
  if (Array.isArray(command.extras)) {
    for (const extra of command.extras) {
      registerCommandModule(extra, file);
    }
  }
  if (!command.data && !command.extras) {
    console.warn(`[Commands] ${file} is missing data or execute`);
  }
}

for (const file of commandFiles) {
  const filePath = path.join(commandsPath, file);
  const command = require(filePath);
  registerCommandModule(command, file);
}

/** Redeploy all slash commands (overwrites old ones) */
async function refreshCommands() {
  const rest = new REST({ version: '10' }).setToken(config.token);

  console.log(`[Commands] Refreshing ${commandJson.length} slash command(s)...`);

  if (config.guildId) {
    const data = await rest.put(
      Routes.applicationGuildCommands(config.clientId, config.guildId),
      { body: commandJson }
    );
    console.log(`[Commands] Reloaded ${data.length} guild command(s) for guild ${config.guildId}`);
  } else {
    const data = await rest.put(
      Routes.applicationCommands(config.clientId),
      { body: commandJson }
    );
    console.log(`[Commands] Reloaded ${data.length} global command(s)`);
  }
}

function applyStatus(c) {
  const type = ACTIVITY_TYPE_MAP[STATUS.type] ?? ActivityType.Listening;
  const activity = { name: STATUS.text, type };
  if (STATUS.type === 'Streaming' && STATUS.url) {
    activity.url = STATUS.url;
  }
  c.user.setActivity(activity);
  console.log(`[Status] ${STATUS.type} ${STATUS.text}`);
}

client.once(Events.ClientReady, async (c) => {
  console.log(`Logged in as ${c.user.tag}`);
  console.log(`Storage mode: ${config.storageType}`);

  try {
    await refreshCommands();
  } catch (err) {
    console.error('[Commands] Failed to refresh commands:', err.message);
  }

  try {
    await initStorage(client);
    console.log('[Storage] Ready');
  } catch (err) {
    console.error('\n========== STORAGE INIT FAILED ==========');
    console.error(err.message);
    if (err.stack) console.error(err.stack);
    console.error('==========================================\n');
    console.error('Tips:');
    console.error('  • STORAGE_TYPE=file   → local JSON (easiest)');
    console.error('  • STORAGE_TYPE=mongodb → needs MONGODB_URI');
    console.error('  • STORAGE_TYPE=discord → needs DATA_CHANNEL_ID + channel perms');
    process.exit(1);
  }

  applyStatus(c);

  setInterval(() => checkExpired(client), 60 * 1000);
  setTimeout(() => checkExpired(client), 5000);
});

// Automod
client.on(Events.MessageCreate, async (message) => {
  try {
    await handleAutomodMessage(message);
  } catch (err) {
    console.error('[Automod] handler error:', err.message);
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  // Button handlers for appeal Accept / Deny / View Case
  if (interaction.isButton() && interaction.customId.startsWith('appeal:')) {
    const parts = interaction.customId.split(':');
    const action = parts[1];
    const appealId = Number(parts[2]);
    const { getStorage } = require('./src/storage');
    const appealCmd = require('./src/commands/appeal');
    const storage = getStorage();

    const staff =
      config.ownerIds.includes(interaction.user.id) ||
      interaction.member.permissions.has('ModerateMembers') ||
      interaction.member.permissions.has('Administrator');

    if (!staff && action !== 'info') {
      return interaction.reply({ content: 'Only staff can review appeals.', ephemeral: true });
    }

    if (action === 'info') {
      const appeal = await storage.getAppeal(interaction.guild.id, appealId);
      if (!appeal) return interaction.reply({ content: 'Appeal not found.', ephemeral: true });
      const caseDoc = await storage.getCase(interaction.guild.id, appeal.caseId);
      const embed = appealCmd.buildAppealEmbed(appeal, caseDoc, null);
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (action === 'accept') {
      await interaction.deferReply({ ephemeral: true });
      const result = await appealCmd.processDecision(
        interaction.client, storage, interaction.guild, appealId, 'accepted', interaction.user, 'Accepted via button'
      );
      return interaction.editReply({ content: result.message });
    }

    if (action === 'deny') {
      const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
      const modal = new ModalBuilder()
        .setCustomId(`appeal:deny_modal:${appealId}`)
        .setTitle(`Deny Appeal #${appealId}`);
      const input = new TextInputBuilder()
        .setCustomId('reason')
        .setLabel('Reason for denial (shown to user)')
        .setStyle(TextInputStyle.Paragraph)
        .setRequired(true)
        .setMinLength(5)
        .setMaxLength(500);
      modal.addComponents(new ActionRowBuilder().addComponents(input));
      return interaction.showModal(modal);
    }
    return;
  }

  if (interaction.isModalSubmit() && interaction.customId.startsWith('appeal:deny_modal:')) {
    const appealId = Number(interaction.customId.split(':')[2]);
    const reason = interaction.fields.getTextInputValue('reason');
    const { getStorage } = require('./src/storage');
    const appealCmd = require('./src/commands/appeal');
    const storage = getStorage();
    await interaction.deferReply({ ephemeral: true });
    const result = await appealCmd.processDecision(
      interaction.client, storage, interaction.guild, appealId, 'denied', interaction.user, reason
    );
    return interaction.editReply({ content: result.message });
  }

  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(`Error executing /${interaction.commandName}:`, error);
    const reply = {
      content: 'There was an error while executing this command.',
      ephemeral: true,
    };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(reply).catch(() => {});
    } else {
      await interaction.reply(reply).catch(() => {});
    }
  }
});

client.login(config.token);
