const mongoose = require('mongoose');

const CaseSchema = new mongoose.Schema({
  guildId: { type: String, required: true, index: true },
  caseId: { type: Number, required: true },
  userId: { type: String, required: true, index: true },
  moderatorId: { type: String, required: true },
  type: { type: String, required: true }, // ban, warn, tempban, softban, mute
  reason: { type: String, default: 'No reason provided' },
  duration: { type: Number, default: null }, // ms, for temp actions
  expiresAt: { type: Date, default: null },
  active: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  extra: { type: mongoose.Schema.Types.Mixed, default: {} }, // e.g. deleteDays for softban
});

CaseSchema.index({ guildId: 1, caseId: 1 }, { unique: true });
CaseSchema.index({ guildId: 1, userId: 1, type: 1, active: 1 });

const CmdPermitSchema = new mongoose.Schema({
  guildId: { type: String, required: true, index: true },
  command: { type: String, required: true }, // e.g. "ban", "ban.add", "warn.list"
  targets: [{
    type: { type: String, enum: ['user', 'role'], required: true },
    id: { type: String, required: true },
  }],
});

CmdPermitSchema.index({ guildId: 1, command: 1 }, { unique: true });


const AppealSchema = new mongoose.Schema({
  guildId: { type: String, required: true, index: true },
  appealId: { type: Number, required: true },
  caseId: { type: Number, required: true },
  userId: { type: String, required: true, index: true },
  reason: { type: String, required: true },
  evidence: { type: String, default: null },
  status: { type: String, enum: ['pending', 'accepted', 'denied', 'withdrawn'], default: 'pending', index: true },
  staffId: { type: String, default: null },
  staffReason: { type: String, default: null },
  messageId: { type: String, default: null },
  channelId: { type: String, default: null },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});
AppealSchema.index({ guildId: 1, appealId: 1 }, { unique: true });

const GuildSettingsSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  appealChannelId: { type: String, default: null },
  appealsEnabled: { type: Boolean, default: true },
  // Full automod config (rules, bypasses, log channel, etc.)
  automod: { type: mongoose.Schema.Types.Mixed, default: {} },
  extra: { type: mongoose.Schema.Types.Mixed, default: {} },
}, { strict: false }); // allow future keys without losing data

const CounterSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  caseCounter: { type: Number, default: 0 },
  appealCounter: { type: Number, default: 0 },
});

class MongoStorage {
  constructor(uri) {
    this.uri = uri;
    this.Case = null;
    this.CmdPermit = null;
    this.Counter = null;
    this.Appeal = null;
    this.GuildSettings = null;
  }

  async init() {
    await mongoose.connect(this.uri);
    this.Case = mongoose.models.Case || mongoose.model('Case', CaseSchema);
    this.CmdPermit = mongoose.models.CmdPermit || mongoose.model('CmdPermit', CmdPermitSchema);
    this.Counter = mongoose.models.Counter || mongoose.model('Counter', CounterSchema);
    this.Appeal = mongoose.models.Appeal || mongoose.model('Appeal', AppealSchema);
    this.GuildSettings = mongoose.models.GuildSettings || mongoose.model('GuildSettings', GuildSettingsSchema);
    console.log('[Storage] Connected to MongoDB');
  }

  async getNextCaseId(guildId) {
    const doc = await this.Counter.findOneAndUpdate(
      { guildId },
      { $inc: { caseCounter: 1 } },
      { upsert: true, new: true }
    );
    return doc.caseCounter;
  }

  async createCase(data) {
    const caseId = await this.getNextCaseId(data.guildId);
    const doc = await this.Case.create({ ...data, caseId });
    return doc.toObject();
  }

  async getCase(guildId, caseId) {
    return this.Case.findOne({ guildId, caseId }).lean();
  }

  async getCasesByUser(guildId, userId, type = null, activeOnly = false) {
    const query = { guildId, userId };
    if (type) query.type = type;
    if (activeOnly) query.active = true;
    return this.Case.find(query).sort({ createdAt: -1 }).lean();
  }

  async getActiveCases(guildId, type, page = 1, pageSize = 50) {
    const skip = (page - 1) * pageSize;
    const [items, total] = await Promise.all([
      this.Case.find({ guildId, type, active: true })
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(pageSize)
        .lean(),
      this.Case.countDocuments({ guildId, type, active: true }),
    ]);
    return { items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) || 1 };
  }

  async updateCase(guildId, caseId, updates) {
    updates.updatedAt = new Date();
    return this.Case.findOneAndUpdate(
      { guildId, caseId },
      { $set: updates },
      { new: true }
    ).lean();
  }

  async deactivateCase(guildId, caseId, reason = null) {
    const updates = { active: false, updatedAt: new Date() };
    if (reason) updates.reason = reason; // or store removeReason separately if needed
    return this.Case.findOneAndUpdate(
      { guildId, caseId },
      { $set: updates },
      { new: true }
    ).lean();
  }

  async findActiveByUser(guildId, userId, type) {
    return this.Case.findOne({ guildId, userId, type, active: true }).lean();
  }

  async getExpiredCases(type) {
    return this.Case.find({
      type,
      active: true,
      expiresAt: { $lte: new Date() },
    }).lean();
  }

  // Command permissions
  async getCmdPermits(guildId) {
    return this.CmdPermit.find({ guildId }).lean();
  }

  async getCmdPermit(guildId, command) {
    return this.CmdPermit.findOne({ guildId, command }).lean();
  }

  async setCmdPermit(guildId, command, targets) {
    return this.CmdPermit.findOneAndUpdate(
      { guildId, command },
      { $set: { targets } },
      { upsert: true, new: true }
    ).lean();
  }

  async removeCmdPermit(guildId, command) {
    return this.CmdPermit.findOneAndDelete({ guildId, command });
  }

  async addCmdPermitTarget(guildId, command, target) {
    const existing = await this.getCmdPermit(guildId, command);
    const targets = existing ? [...existing.targets] : [];
    if (!targets.some(t => t.type === target.type && t.id === target.id)) {
      targets.push(target);
    }
    return this.setCmdPermit(guildId, command, targets);
  }

  async removeCmdPermitTarget(guildId, command, target) {
    const existing = await this.getCmdPermit(guildId, command);
    if (!existing) return null;
    const targets = existing.targets.filter(
      t => !(t.type === target.type && t.id === target.id)
    );
    if (targets.length === 0) {
      await this.removeCmdPermit(guildId, command);
      return null;
    }
    return this.setCmdPermit(guildId, command, targets);
  }

  async getNextAppealId(guildId) {
    const doc = await this.Counter.findOneAndUpdate(
      { guildId },
      { $inc: { appealCounter: 1 } },
      { upsert: true, new: true }
    );
    return doc.appealCounter;
  }

  async createAppeal(data) {
    const appealId = await this.getNextAppealId(data.guildId);
    const doc = await this.Appeal.create({ ...data, appealId });
    return doc.toObject();
  }

  async getAppeal(guildId, appealId) {
    return this.Appeal.findOne({ guildId, appealId: Number(appealId) }).lean();
  }

  async updateAppeal(guildId, appealId, updates) {
    updates.updatedAt = new Date();
    return this.Appeal.findOneAndUpdate(
      { guildId, appealId: Number(appealId) },
      { $set: updates },
      { new: true }
    ).lean();
  }

  async getAppealsByUser(guildId, userId) {
    return this.Appeal.find({ guildId, userId }).sort({ createdAt: -1 }).lean();
  }

  async getAppealsByCase(guildId, caseId) {
    return this.Appeal.find({ guildId, caseId: Number(caseId) }).lean();
  }

  async getAppeals(guildId, status = null, page = 1, pageSize = 50) {
    const query = { guildId };
    if (status) query.status = status;
    const skip = (page - 1) * pageSize;
    const [items, total] = await Promise.all([
      this.Appeal.find(query).sort({ createdAt: -1 }).skip(skip).limit(pageSize).lean(),
      this.Appeal.countDocuments(query),
    ]);
    return { items, total, page, pageSize, totalPages: Math.ceil(total / pageSize) || 1 };
  }

  async getGuildSettings(guildId) {
    const doc = await this.GuildSettings.findOne({ guildId }).lean();
    if (!doc) return {};
    // Strip mongoose internals — return only settings fields
    const { _id, __v, guildId: _g, ...rest } = doc;
    return rest;
  }

  async setGuildSettings(guildId, patch) {
    // Shallow-merge top-level keys; replace nested objects like automod wholesale
    // when provided (callers pass full automod config).
    const update = { $set: {} };
    for (const [k, v] of Object.entries(patch)) {
      update.$set[k] = v;
    }
    update.$set.guildId = guildId;
    const doc = await this.GuildSettings.findOneAndUpdate(
      { guildId },
      update,
      { upsert: true, new: true }
    ).lean();
    const { _id, __v, guildId: _g, ...rest } = doc || {};
    return rest;
  }

}

module.exports = MongoStorage;
