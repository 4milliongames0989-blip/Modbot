const config = require('../config');
const MongoStorage = require('./mongo');
const DiscordFileStorage = require('./discordFile');
const LocalFileStorage = require('./localFile');

let storage = null;

/**
 * Init storage used by cases, appeals, cmdpermits, AND automod.
 *
 * STORAGE_TYPE:
 *   discord  → requires DATA_CHANNEL_ID (uploads modbot-data.json to that channel)
 *   file     → local ./data/modbot-data.json
 *   mongodb  → requires MONGODB_URI
 */
async function initStorage(client) {
  const type = (config.storageType || 'file').toLowerCase();

  if (type === 'discord') {
    if (!config.dataChannelId) {
      throw new Error(
        'STORAGE_TYPE=discord requires DATA_CHANNEL_ID in .env\n' +
        '  1. Create a private text channel (e.g. #bot-data)\n' +
        '  2. Enable Developer Mode → right-click channel → Copy Channel ID\n' +
        '  3. Set DATA_CHANNEL_ID=that_id in .env\n' +
        '  4. Give the bot: View Channel, Send Messages, Attach Files, Read Message History'
      );
    }
    storage = new DiscordFileStorage(client, config.dataChannelId);
  } else if (type === 'file' || type === 'local' || type === 'json') {
    storage = new LocalFileStorage();
  } else if (type === 'mongodb' || type === 'mongo') {
    storage = new MongoStorage(config.mongoUri);
  } else {
    throw new Error(
      `Unknown STORAGE_TYPE="${type}". Use: discord | file | mongodb`
    );
  }

  await storage.init();
  console.log(`[Storage] Active backend: ${type}`);
  return storage;
}

function getStorage() {
  if (!storage) {
    throw new Error('Storage not initialized. Wait for the bot ready event / initStorage().');
  }
  return storage;
}

module.exports = { initStorage, getStorage };
