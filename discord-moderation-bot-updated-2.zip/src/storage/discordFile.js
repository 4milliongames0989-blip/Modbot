const { AttachmentBuilder } = require('discord.js');

/**
 * Stores all data as a single JSON file uploaded to a Discord channel.
 * The latest message with the attachment is treated as the current state.
 * On every write we re-upload a new version.
 */
class DiscordFileStorage {
  constructor(client, channelId) {
    this.client = client;
    // Strip quotes / whitespace that often sneak into .env values
    this.channelId = String(channelId || '').replace(/['"]/g, '').trim();
    this.data = {
      cases: [],
      appeals: [],
      cmdPermits: [],
      counters: {}, // guildId -> caseCounter
      settings: {},
    };
    this.messageId = null;
    this.dirty = false;
    this.saveLock = false;
  }

  async init() {
    if (!this.channelId) {
      throw new Error(
        'DATA_CHANNEL_ID is empty.\n' +
        '  → Open Discord → right-click the channel → Copy Channel ID\n' +
        '  → Paste it into .env as DATA_CHANNEL_ID=123456789012345678\n' +
        '  → Make sure Developer Mode is enabled (User Settings → Advanced)'
      );
    }

    if (!/^\d{17,20}$/.test(this.channelId)) {
      throw new Error(
        `DATA_CHANNEL_ID looks invalid: "${this.channelId}"\n` +
        '  → It must be a numeric snowflake (17–20 digits), e.g. 123456789012345678\n' +
        '  → No quotes, no spaces, no channel name'
      );
    }

    let channel;
    try {
      channel = await this.client.channels.fetch(this.channelId);
    } catch (err) {
      throw new Error(
        `Could not fetch data channel ${this.channelId}.\n` +
        `  Discord error: ${err.message}\n` +
        '  Checklist:\n' +
        '  1. The bot is invited to the server that owns this channel\n' +
        '  2. The channel still exists (not deleted)\n' +
        '  3. The bot role can VIEW the channel (View Channel permission)\n' +
        '  4. You copied the CHANNEL id, not the server (guild) id'
      );
    }

    if (!channel) {
      throw new Error(`Data channel ${this.channelId} returned null (bot cannot see it).`);
    }

    if (!channel.isTextBased()) {
      throw new Error(
        `Channel ${this.channelId} is not a text channel (type: ${channel.type}).\n` +
        '  → Use a normal text channel or a news channel, not a voice/stage/forum thread without text.'
      );
    }

    // Check we can actually send + attach
    const me = channel.guild
      ? channel.guild.members.me || await channel.guild.members.fetchMe().catch(() => null)
      : null;

    if (me) {
      const perms = channel.permissionsFor(me);
      const missing = [];
      if (!perms.has('ViewChannel')) missing.push('View Channel');
      if (!perms.has('SendMessages')) missing.push('Send Messages');
      if (!perms.has('AttachFiles')) missing.push('Attach Files');
      if (!perms.has('ReadMessageHistory')) missing.push('Read Message History');
      if (missing.length) {
        throw new Error(
          `Bot is missing permissions in #${channel.name}: ${missing.join(', ')}\n` +
          '  → Give the bot role those permissions in the channel or category'
        );
      }
    }

    this.channel = channel;
    console.log(`[Storage] Using Discord channel #${channel.name} (${channel.id})`);

    // Find the latest data message
    let messages;
    try {
      messages = await channel.messages.fetch({ limit: 20 });
    } catch (err) {
      throw new Error(
        `Cannot read messages in the data channel: ${err.message}\n` +
        '  → Grant the bot "Read Message History" in that channel'
      );
    }

    const dataMsg = messages.find(m =>
      m.author.id === this.client.user.id &&
      m.attachments.some(a => a.name === 'modbot-data.json')
    );

    if (dataMsg) {
      this.messageId = dataMsg.id;
      const attachment = dataMsg.attachments.find(a => a.name === 'modbot-data.json');
      if (attachment) {
        try {
          const res = await fetch(attachment.url);
          const json = await res.json();
          this.data = {
            cases: json.cases || [],
            appeals: json.appeals || [],
            cmdPermits: json.cmdPermits || [],
            counters: json.counters || {},
            settings: json.settings || {},
          };
          const guildCount = Object.keys(this.data.settings).length;
          console.log(
            `[Storage] Loaded Discord file storage ` +
            `(${this.data.cases.length} cases, ${this.data.appeals.length} appeals, ${guildCount} guild setting(s) incl. automod)`
          );
        } catch (err) {
          console.warn('[Storage] Failed to parse existing data file, starting fresh:', err.message);
          await this.save();
        }
      }
    } else {
      console.log('[Storage] No existing data file found, starting fresh');
      await this.save();
    }
  }

  async save() {
    if (this.saveLock) return;
    this.saveLock = true;
    try {
      const buffer = Buffer.from(JSON.stringify(this.data, null, 2), 'utf8');
      const file = new AttachmentBuilder(buffer, { name: 'modbot-data.json' });

      // Delete old message if exists
      if (this.messageId) {
        try {
          const old = await this.channel.messages.fetch(this.messageId);
          await old.delete().catch(() => {});
        } catch (_) {}
      }

      const g = Object.keys(this.data.settings || {}).length;
      const msg = await this.channel.send({
        content:
          `ModBot data backup — ${new Date().toISOString()}\n` +
          `cases: ${(this.data.cases || []).length} · appeals: ${(this.data.appeals || []).length} · ` +
          `settings/automod guilds: ${g}`,
        files: [file],
      });
      this.messageId = msg.id;
      this.dirty = false;
    } finally {
      this.saveLock = false;
    }
  }

  async getNextCaseId(guildId) {
    if (!this.data.counters[guildId]) this.data.counters[guildId] = 0;
    this.data.counters[guildId] += 1;
    await this.save();
    return this.data.counters[guildId];
  }

  async createCase(data) {
    const caseId = await this.getNextCaseId(data.guildId);
    const doc = {
      ...data,
      caseId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      active: data.active !== false,
    };
    this.data.cases.push(doc);
    await this.save();
    return doc;
  }

  async getCase(guildId, caseId) {
    return this.data.cases.find(c => c.guildId === guildId && c.caseId === Number(caseId)) || null;
  }

  async getCasesByUser(guildId, userId, type = null, activeOnly = false) {
    return this.data.cases
      .filter(c => {
        if (c.guildId !== guildId || c.userId !== userId) return false;
        if (type && c.type !== type) return false;
        if (activeOnly && !c.active) return false;
        return true;
      })
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  async getActiveCases(guildId, type, page = 1, pageSize = 50) {
    const filtered = this.data.cases
      .filter(c => c.guildId === guildId && c.type === type && c.active)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const total = filtered.length;
    const totalPages = Math.ceil(total / pageSize) || 1;
    const skip = (page - 1) * pageSize;
    const items = filtered.slice(skip, skip + pageSize);
    return { items, total, page, pageSize, totalPages };
  }

  async updateCase(guildId, caseId, updates) {
    const idx = this.data.cases.findIndex(c => c.guildId === guildId && c.caseId === Number(caseId));
    if (idx === -1) return null;
    this.data.cases[idx] = {
      ...this.data.cases[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    await this.save();
    return this.data.cases[idx];
  }

  async deactivateCase(guildId, caseId) {
    return this.updateCase(guildId, caseId, { active: false });
  }

  async findActiveByUser(guildId, userId, type) {
    return this.data.cases.find(
      c => c.guildId === guildId && c.userId === userId && c.type === type && c.active
    ) || null;
  }

  async getExpiredCases(type) {
    const now = Date.now();
    return this.data.cases.filter(c =>
      c.type === type &&
      c.active &&
      c.expiresAt &&
      new Date(c.expiresAt).getTime() <= now
    );
  }

  // Command permissions
  async getCmdPermits(guildId) {
    return this.data.cmdPermits.filter(p => p.guildId === guildId);
  }

  async getCmdPermit(guildId, command) {
    return this.data.cmdPermits.find(p => p.guildId === guildId && p.command === command) || null;
  }

  async setCmdPermit(guildId, command, targets) {
    const idx = this.data.cmdPermits.findIndex(p => p.guildId === guildId && p.command === command);
    const doc = { guildId, command, targets };
    if (idx >= 0) {
      this.data.cmdPermits[idx] = doc;
    } else {
      this.data.cmdPermits.push(doc);
    }
    await this.save();
    return doc;
  }

  async removeCmdPermit(guildId, command) {
    this.data.cmdPermits = this.data.cmdPermits.filter(
      p => !(p.guildId === guildId && p.command === command)
    );
    await this.save();
  }

  async addCmdPermitTarget(guildId, command, target) {
    const existing = await this.getCmdPermit(guildId, command);
    const targets = existing ? [...existing.targets] : [];
    if (!targets.some(t => t.type === target.type && t.id === target.id)) {
      targets.push(target);
    }
    return this.setCmdPermit(guildId, command, targets);
  }

  async removeCmdPermitTarget(guildId, command, target) {
    const existing = await this.getCmdPermit(guildId, command);
    if (!existing) return null;
    const targets = existing.targets.filter(
      t => !(t.type === target.type && t.id === target.id)
    );
    if (targets.length === 0) {
      await this.removeCmdPermit(guildId, command);
      return null;
    }
    return this.setCmdPermit(guildId, command, targets);
  }

  // ── Appeals ──────────────────────────────────────────────
  async getNextAppealId(guildId) {
    const key = guildId + ':appeal';
    if (!this.data.counters[key]) this.data.counters[key] = 0;
    this.data.counters[key] += 1;
    await this.save();
    return this.data.counters[key];
  }

  async createAppeal(data) {
    if (!this.data.appeals) this.data.appeals = [];
    const appealId = await this.getNextAppealId(data.guildId);
    const doc = {
      ...data,
      appealId,
      status: data.status || 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.data.appeals.push(doc);
    await this.save();
    return doc;
  }

  async getAppeal(guildId, appealId) {
    if (!this.data.appeals) return null;
    return this.data.appeals.find(a => a.guildId === guildId && a.appealId === Number(appealId)) || null;
  }

  async updateAppeal(guildId, appealId, updates) {
    if (!this.data.appeals) return null;
    const idx = this.data.appeals.findIndex(a => a.guildId === guildId && a.appealId === Number(appealId));
    if (idx === -1) return null;
    this.data.appeals[idx] = {
      ...this.data.appeals[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    await this.save();
    return this.data.appeals[idx];
  }

  async getAppealsByUser(guildId, userId) {
    if (!this.data.appeals) return [];
    return this.data.appeals
      .filter(a => a.guildId === guildId && a.userId === userId)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  async getAppealsByCase(guildId, caseId) {
    if (!this.data.appeals) return [];
    return this.data.appeals.filter(a => a.guildId === guildId && a.caseId === Number(caseId));
  }

  async getAppeals(guildId, status = null, page = 1, pageSize = 50) {
    if (!this.data.appeals) return { items: [], total: 0, page, pageSize, totalPages: 1 };
    let filtered = this.data.appeals.filter(a => a.guildId === guildId);
    if (status) filtered = filtered.filter(a => a.status === status);
    filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const total = filtered.length;
    const totalPages = Math.ceil(total / pageSize) || 1;
    const skip = (page - 1) * pageSize;
    return { items: filtered.slice(skip, skip + pageSize), total, page, pageSize, totalPages };
  }

  async getGuildSettings(guildId) {
    if (!this.data.settings) this.data.settings = {};
    return this.data.settings[guildId] || {};
  }

  async setGuildSettings(guildId, patch) {
    if (!this.data.settings) this.data.settings = {};
    const prev = this.data.settings[guildId] || {};
    // JSON clone so nested automod/rules always persist cleanly
    const merged = JSON.parse(JSON.stringify({ ...prev, ...patch }));
    this.data.settings[guildId] = merged;
    await this.save();
    return this.data.settings[guildId];
  }

}

module.exports = DiscordFileStorage;
