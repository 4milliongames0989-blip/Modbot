const fs = require('fs');
const path = require('path');

/**
 * Simple local JSON file storage.
 * Writes to ./data/modbot-data.json (created automatically).
 * No Discord channel or MongoDB required.
 */
class LocalFileStorage {
  constructor(filePath) {
    this.filePath = filePath || path.join(process.cwd(), 'data', 'modbot-data.json');
    this.data = {
      cases: [],
      appeals: [],
      cmdPermits: [],
      counters: {},
      settings: {},
    };
  }

  async init() {
    const dir = path.dirname(this.filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    if (fs.existsSync(this.filePath)) {
      try {
        const raw = fs.readFileSync(this.filePath, 'utf8');
        const json = JSON.parse(raw);
        this.data = {
          cases: json.cases || [],
          appeals: json.appeals || [],
          cmdPermits: json.cmdPermits || [],
          counters: json.counters || {},
          settings: json.settings || {},
        };
        console.log(`[Storage] Loaded local file (${this.data.cases.length} cases) → ${this.filePath}`);
      } catch (err) {
        console.warn('[Storage] Could not parse existing data file, starting fresh:', err.message);
        this.saveSync();
      }
    } else {
      console.log(`[Storage] No data file yet, creating → ${this.filePath}`);
      this.saveSync();
    }
  }

  saveSync() {
    const dir = path.dirname(this.filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2), 'utf8');
  }

  async save() {
    this.saveSync();
  }

  async getNextCaseId(guildId) {
    if (!this.data.counters[guildId]) this.data.counters[guildId] = 0;
    this.data.counters[guildId] += 1;
    await this.save();
    return this.data.counters[guildId];
  }

  async createCase(data) {
    const caseId = await this.getNextCaseId(data.guildId);
    const doc = {
      ...data,
      caseId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      active: data.active !== false,
    };
    this.data.cases.push(doc);
    await this.save();
    return doc;
  }

  async getCase(guildId, caseId) {
    return this.data.cases.find(c => c.guildId === guildId && c.caseId === Number(caseId)) || null;
  }

  async getCasesByUser(guildId, userId, type = null, activeOnly = false) {
    return this.data.cases
      .filter(c => {
        if (c.guildId !== guildId || c.userId !== userId) return false;
        if (type && c.type !== type) return false;
        if (activeOnly && !c.active) return false;
        return true;
      })
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  async getActiveCases(guildId, type, page = 1, pageSize = 50) {
    const filtered = this.data.cases
      .filter(c => c.guildId === guildId && c.type === type && c.active)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const total = filtered.length;
    const totalPages = Math.ceil(total / pageSize) || 1;
    const skip = (page - 1) * pageSize;
    const items = filtered.slice(skip, skip + pageSize);
    return { items, total, page, pageSize, totalPages };
  }

  async updateCase(guildId, caseId, updates) {
    const idx = this.data.cases.findIndex(c => c.guildId === guildId && c.caseId === Number(caseId));
    if (idx === -1) return null;
    this.data.cases[idx] = {
      ...this.data.cases[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    await this.save();
    return this.data.cases[idx];
  }

  async deactivateCase(guildId, caseId) {
    return this.updateCase(guildId, caseId, { active: false });
  }

  async findActiveByUser(guildId, userId, type) {
    return this.data.cases.find(
      c => c.guildId === guildId && c.userId === userId && c.type === type && c.active
    ) || null;
  }

  async getExpiredCases(type) {
    const now = Date.now();
    return this.data.cases.filter(c =>
      c.type === type &&
      c.active &&
      c.expiresAt &&
      new Date(c.expiresAt).getTime() <= now
    );
  }

  async getCmdPermits(guildId) {
    return this.data.cmdPermits.filter(p => p.guildId === guildId);
  }

  async getCmdPermit(guildId, command) {
    return this.data.cmdPermits.find(p => p.guildId === guildId && p.command === command) || null;
  }

  async setCmdPermit(guildId, command, targets) {
    const idx = this.data.cmdPermits.findIndex(p => p.guildId === guildId && p.command === command);
    const doc = { guildId, command, targets };
    if (idx >= 0) {
      this.data.cmdPermits[idx] = doc;
    } else {
      this.data.cmdPermits.push(doc);
    }
    await this.save();
    return doc;
  }

  async removeCmdPermit(guildId, command) {
    this.data.cmdPermits = this.data.cmdPermits.filter(
      p => !(p.guildId === guildId && p.command === command)
    );
    await this.save();
  }

  async addCmdPermitTarget(guildId, command, target) {
    const existing = await this.getCmdPermit(guildId, command);
    const targets = existing ? [...existing.targets] : [];
    if (!targets.some(t => t.type === target.type && t.id === target.id)) {
      targets.push(target);
    }
    return this.setCmdPermit(guildId, command, targets);
  }

  async removeCmdPermitTarget(guildId, command, target) {
    const existing = await this.getCmdPermit(guildId, command);
    if (!existing) return null;
    const targets = existing.targets.filter(
      t => !(t.type === target.type && t.id === target.id)
    );
    if (targets.length === 0) {
      await this.removeCmdPermit(guildId, command);
      return null;
    }
    return this.setCmdPermit(guildId, command, targets);
  }

  // ── Appeals ──────────────────────────────────────────────
  async getNextAppealId(guildId) {
    const key = guildId + ':appeal';
    if (!this.data.counters[key]) this.data.counters[key] = 0;
    this.data.counters[key] += 1;
    await this.save();
    return this.data.counters[key];
  }

  async createAppeal(data) {
    if (!this.data.appeals) this.data.appeals = [];
    const appealId = await this.getNextAppealId(data.guildId);
    const doc = {
      ...data,
      appealId,
      status: data.status || 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.data.appeals.push(doc);
    await this.save();
    return doc;
  }

  async getAppeal(guildId, appealId) {
    if (!this.data.appeals) return null;
    return this.data.appeals.find(a => a.guildId === guildId && a.appealId === Number(appealId)) || null;
  }

  async updateAppeal(guildId, appealId, updates) {
    if (!this.data.appeals) return null;
    const idx = this.data.appeals.findIndex(a => a.guildId === guildId && a.appealId === Number(appealId));
    if (idx === -1) return null;
    this.data.appeals[idx] = {
      ...this.data.appeals[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    await this.save();
    return this.data.appeals[idx];
  }

  async getAppealsByUser(guildId, userId) {
    if (!this.data.appeals) return [];
    return this.data.appeals
      .filter(a => a.guildId === guildId && a.userId === userId)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  async getAppealsByCase(guildId, caseId) {
    if (!this.data.appeals) return [];
    return this.data.appeals.filter(a => a.guildId === guildId && a.caseId === Number(caseId));
  }

  async getAppeals(guildId, status = null, page = 1, pageSize = 50) {
    if (!this.data.appeals) return { items: [], total: 0, page, pageSize, totalPages: 1 };
    let filtered = this.data.appeals.filter(a => a.guildId === guildId);
    if (status) filtered = filtered.filter(a => a.status === status);
    filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const total = filtered.length;
    const totalPages = Math.ceil(total / pageSize) || 1;
    const skip = (page - 1) * pageSize;
    return { items: filtered.slice(skip, skip + pageSize), total, page, pageSize, totalPages };
  }

  // ── Guild settings ───────────────────────────────────────
  async getGuildSettings(guildId) {
    if (!this.data.settings) this.data.settings = {};
    return this.data.settings[guildId] || {};
  }

  async setGuildSettings(guildId, patch) {
    if (!this.data.settings) this.data.settings = {};
    const prev = this.data.settings[guildId] || {};
    // JSON clone so nested automod/rules always persist cleanly
    const merged = JSON.parse(JSON.stringify({ ...prev, ...patch }));
    this.data.settings[guildId] = merged;
    await this.save();
    return this.data.settings[guildId];
  }

}

module.exports = LocalFileStorage;
