const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warns')
    .setDescription('View warnings')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List all warned users (50 per page)')
        .addIntegerOption(o =>
          o.setName('page').setDescription('Page number').setMinValue(1)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('user')
        .setDescription('Show all warns for a specific user')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const guild = interaction.guild;

    const cmdKey = sub === 'list' ? 'warns.list' : 'warns.user';
    if (!(await canRunCommand(interaction.member, cmdKey))) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const page = interaction.options.getInteger('page') || 1;
      // Aggregate unique users who have active warns
      const result = await storage.getActiveCases(guild.id, 'warn', page, config.pageSize);

      if (result.total === 0) {
        return interaction.reply({ content: 'No active warnings.', ephemeral: true });
      }

      // Group by user for nicer display
      const byUser = {};
      for (const c of result.items) {
        if (!byUser[c.userId]) byUser[c.userId] = [];
        byUser[c.userId].push(c);
      }

      const lines = Object.entries(byUser).map(([uid, cases]) => {
        return `<@${uid}> — ${cases.length} warn(s) (latest: #${cases[0].caseId})`;
      });

      const embed = new EmbedBuilder()
        .setColor(0xf1c40f)
        .setTitle(`Warned Users — Page ${result.page}/${result.totalPages}`)
        .setDescription(lines.join('\n') || 'None')
        .setFooter({ text: `Total active warn cases: ${result.total}` });

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'user') {
      const user = interaction.options.getUser('user', true);
      const cases = await storage.getCasesByUser(guild.id, user.id, 'warn');

      if (cases.length === 0) {
        return interaction.reply({ content: `${user.tag} has no warnings.`, ephemeral: true });
      }

      const lines = cases.map(c => {
        const status = c.active ? '🟢' : '🔴';
        const date = new Date(c.createdAt).toLocaleDateString();
        return `${status} **#${c.caseId}** — ${c.reason.slice(0, 80)}${c.reason.length > 80 ? '…' : ''} (${date}) by <@${c.moderatorId}>`;
      });

      const embed = new EmbedBuilder()
        .setColor(0xf1c40f)
        .setTitle(`Warnings for ${user.tag}`)
        .setDescription(lines.slice(0, 20).join('\n'))
        .setFooter({ text: `Total: ${cases.length} (showing up to 20)` });

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
