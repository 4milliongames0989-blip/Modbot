/**
 * AutoMod — single file with interactive control panel.
 * Place at: src/commands/automod.js
 *
 * Usage: /automod  → opens the management panel
 * Anti-link: blocks ALL links except domains you allowlist.
 */
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  RoleSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelType,
  ComponentType,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const { parseDuration, formatDuration } = require('../utils/duration');
const { sendPunishmentDM } = require('../utils/dm');

const ACTIONS = ['delete', 'warn', 'mute', 'kick', 'ban', 'softban', 'tempban'];

const RULE_META = {
  antilink: { name: 'Anti Link', description: 'Blocks all links except allowlisted domains' },
  capsspam: { name: 'Caps Spam', description: 'Excessive uppercase' },
  channelspam: { name: 'Channel Spam', description: 'Posting in many channels quickly' },
  spam: { name: 'Spam', description: 'Rapid messages in one channel' },
  antiinvite: { name: 'Anti Invite', description: 'Discord invite links' },
  massmention: { name: 'Mass Mention', description: 'Too many @users' },
  emojispam: { name: 'Emoji Spam', description: 'Too many emojis' },
  badwords: { name: 'Bad Words', description: 'Banned word filter' },
  zalgo: { name: 'Zalgo', description: 'Cursed / combining text' },
  duplicates: { name: 'Duplicates', description: 'Repeated messages' },
  newlines: { name: 'Newlines', description: 'Excessive line breaks' },
  everyone: { name: 'Everyone/Here', description: '@everyone without permission' },
  attachments: { name: 'Attachments', description: 'File limits / blocked types' },
  stickers: { name: 'Stickers', description: 'Too many stickers' },
};

const DEFAULT_CONFIG = {
  enabled: false,
  logChannelId: null,
  ignoredChannels: [],
  ignoredRoles: [],
  ignoreAdmins: true,
  ignoreBots: true,
  defaultAction: 'warn',
  defaultMuteDuration: '10m',
  defaultTempbanDuration: '1d',
  deleteMessage: true,
  rules: {
    antilink: { enabled: false, action: null, duration: null, allowDiscordLinks: false, allowedDomains: [] },
    capsspam: { enabled: false, action: null, duration: null, minLength: 10, maxPercent: 70 },
    channelspam: { enabled: false, action: null, duration: null, maxChannels: 4, windowSeconds: 10 },
    spam: { enabled: false, action: null, duration: null, maxMessages: 5, windowSeconds: 5 },
    antiinvite: { enabled: false, action: null, duration: null },
    massmention: { enabled: false, action: null, duration: null, maxMentions: 5 },
    emojispam: { enabled: false, action: null, duration: null, maxEmojis: 8 },
    badwords: { enabled: false, action: null, duration: null, words: [], matchPartial: false },
    zalgo: { enabled: false, action: null, duration: null, maxCombining: 6 },
    duplicates: { enabled: false, action: null, duration: null, maxRepeats: 3, windowSeconds: 30 },
    newlines: { enabled: false, action: null, duration: null, maxNewlines: 8 },
    everyone: { enabled: false, action: null, duration: null },
    attachments: { enabled: false, action: null, duration: null, maxAttachments: 5, blockedExtensions: ['exe', 'bat', 'cmd', 'scr', 'js', 'vbs', 'msi'] },
    stickers: { enabled: false, action: null, duration: null, maxStickers: 3 },
  },
  ruleBypasses: {},
};

function mergeConfig(stored) {
  const base = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  if (!stored || typeof stored !== 'object') return base;
  const out = { ...base, ...stored, rules: { ...base.rules } };
  if (stored.rules) {
    for (const [k, v] of Object.entries(stored.rules)) {
      out.rules[k] = { ...(base.rules[k] || {}), ...v };
    }
  }
  out.ignoredChannels = stored.ignoredChannels || [];
  out.ignoredRoles = stored.ignoredRoles || [];
  out.ruleBypasses = stored.ruleBypasses || {};
  return out;
}

/**
 * Load / save automod config via the bot's storage layer
 * (local JSON file, MongoDB, or Discord channel file — same as cases/appeals).
 */
async function loadCfg(guildId) {
  const storage = getStorage();
  const settings = await storage.getGuildSettings(guildId);
  return { storage, cfg: mergeConfig(settings.automod) };
}

async function saveCfg(guildId, cfg) {
  const storage = getStorage();
  // Persist full automod object under settings[guildId].automod
  await storage.setGuildSettings(guildId, {
    automod: JSON.parse(JSON.stringify(cfg)),
  });
}

async function canManage(member) {
  if (!member) return false;
  const { ownerIds } = require('../config');
  if (ownerIds?.includes(member.id)) return true;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (member.permissions.has(PermissionFlagsBits.ManageGuild)) return true;
  return canRunCommand(member, 'automod');
}

// ─── Panel UI builders ───────────────────────────────────────

function mainEmbed(cfg, guild) {
  const on = Object.entries(cfg.rules).filter(([, r]) => r.enabled).length;
  const lines = Object.keys(RULE_META).map(k => {
    const r = cfg.rules[k] || {};
    return `${r.enabled ? '🟢' : '⚫'} **${RULE_META[k].name}** → \`${r.action || cfg.defaultAction}\``;
  });
  return new EmbedBuilder()
    .setColor(cfg.enabled ? 0x2ecc71 : 0x95a5a6)
    .setTitle(`AutoMod Panel — ${guild.name}`)
    .setDescription(
      `**Status:** ${cfg.enabled ? '🟢 Enabled' : '🔴 Disabled'}\n` +
      `**Log:** ${cfg.logChannelId ? `<#${cfg.logChannelId}>` : '*not set*'}\n` +
      `**Default action:** \`${cfg.defaultAction}\` · Mute \`${cfg.defaultMuteDuration}\` · Tempban \`${cfg.defaultTempbanDuration}\`\n` +
      `**Rules on:** ${on}/${Object.keys(RULE_META).length}\n\n` +
      lines.join('\n')
    )
    .setFooter({ text: 'Use the buttons below to manage everything' })
    .setTimestamp();
}

function mainComponents(cfg) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('am:toggle')
        .setLabel(cfg.enabled ? 'Disable AutoMod' : 'Enable AutoMod')
        .setStyle(cfg.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
      new ButtonBuilder().setCustomId('am:log').setLabel('Set Log Channel').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('am:defaults').setLabel('Defaults').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('am:refresh').setLabel('Refresh').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('am:rules').setLabel('Configure Rules').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('am:bypass').setLabel('Bypasses').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('am:words').setLabel('Bad Words').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('am:domains').setLabel('Allowed Links').setStyle(ButtonStyle.Secondary),
    ),
  ];
}

function rulesSelectRow() {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('am:rulepick')
      .setPlaceholder('Select a rule to configure…')
      .addOptions(
        Object.entries(RULE_META).map(([k, v]) => ({
          label: v.name,
          description: v.description.slice(0, 100),
          value: k,
        }))
      )
  );
}

function ruleEmbed(cfg, ruleKey) {
  const r = cfg.rules[ruleKey] || {};
  const meta = RULE_META[ruleKey];
  const fields = [
    { name: 'Enabled', value: r.enabled ? '🟢 Yes' : '🔴 No', inline: true },
    { name: 'Action', value: `\`${r.action || cfg.defaultAction}\``, inline: true },
    { name: 'Duration', value: r.duration || cfg.defaultMuteDuration + ' / ' + cfg.defaultTempbanDuration, inline: true },
  ];
  if (ruleKey === 'antilink') {
    const domains = r.allowedDomains?.length ? r.allowedDomains.map(d => `\`${d}\``).join(', ') : '*none — all links blocked*';
    fields.push(
      { name: 'Allow Discord links', value: String(!!r.allowDiscordLinks), inline: true },
      { name: 'Allowed domains', value: domains },
    );
  }
  if (ruleKey === 'spam') {
    fields.push({ name: 'Threshold', value: `${r.maxMessages || 5} msgs / ${r.windowSeconds || 5}s`, inline: true });
  }
  if (ruleKey === 'capsspam') {
    fields.push({ name: 'Threshold', value: `${r.maxPercent || 70}% caps, min ${r.minLength || 10} letters`, inline: true });
  }
  if (ruleKey === 'badwords') {
    fields.push({ name: 'Words', value: r.words?.length ? r.words.slice(0, 20).map(w => `\`${w}\``).join(', ') : '*none*', inline: false });
  }
  return new EmbedBuilder()
    .setColor(r.enabled ? 0x3498db : 0x95a5a6)
    .setTitle(`Rule: ${meta.name}`)
    .setDescription(meta.description)
    .addFields(fields)
    .setFooter({ text: `Key: ${ruleKey}` });
}

function ruleComponents(ruleKey, cfg) {
  const r = cfg.rules[ruleKey] || {};
  const rows = [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`am:ruletoggle:${ruleKey}`)
        .setLabel(r.enabled ? 'Disable Rule' : 'Enable Rule')
        .setStyle(r.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`am:ruleaction:${ruleKey}`).setLabel('Set Action').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`am:ruleduration:${ruleKey}`).setLabel('Set Duration').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`am:rulethresh:${ruleKey}`).setLabel('Thresholds').setStyle(ButtonStyle.Secondary),
    ),
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('am:rules').setLabel('← Back to rules').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('am:home').setLabel('Main Panel').setStyle(ButtonStyle.Secondary),
    ),
  ];
  if (ruleKey === 'antilink') {
    rows.splice(1, 0, new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`am:rulediscord:${ruleKey}`)
        .setLabel(r.allowDiscordLinks ? 'Discord links: ON' : 'Discord links: OFF')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('am:domains').setLabel('Edit Allowed Domains').setStyle(ButtonStyle.Primary),
    ));
  }
  return rows;
}

function actionSelectRow(ruleKey) {
  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`am:setaction:${ruleKey}`)
      .setPlaceholder('Choose punishment action…')
      .addOptions(ACTIONS.map(a => ({ label: a, value: a })))
  );
}

// ─── Trackers ────────────────────────────────────────────────

const spamTracker = new Map();
const channelSpamTracker = new Map();
const dupTracker = new Map();

function trackPush(map, key, value, windowMs) {
  const now = Date.now();
  let arr = map.get(key) || [];
  arr = arr.filter(t => now - t < windowMs);
  arr.push(value);
  map.set(key, arr);
  return arr;
}

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function ruleEnabled(cfg, rule) {
  return cfg.rules[rule]?.enabled;
}

function isRuleBypassed(message, cfg, rule) {
  const bp = cfg.ruleBypasses?.[rule];
  if (!bp) return false;
  if (bp.channels?.includes(message.channel.id)) return true;
  if (bp.roles && message.member.roles.cache.some(r => bp.roles.includes(r.id))) return true;
  return false;
}

// ─── Rule checks ─────────────────────────────────────────────

/**
 * Extract possible links / domains from message text (many formats).
 * Catches: https://, http://, www., bare youtube.com, markdown [x](url),
 *          youtube[.]com, youtube(dot)com, hxxp://, <url>, etc.
 */
function extractLinks(content) {
  if (!content) return [];
  let text = content;

  // Un-obfuscate common tricks
  text = text
    .replace(/\[(?:dot|\.)\]/gi, '.')
    .replace(/\(dot\)/gi, '.')
    .replace(/\{dot\}/gi, '.')
    .replace(/\s*\(\s*dot\s*\)\s*/gi, '.')
    .replace(/hxxps?:\/\//gi, 'http://')
    .replace(/\[\/?(?:url|link)\]/gi, ' ');

  // Markdown links [label](url)
  const mdLinks = [];
  text.replace(/\[([^\]]*)\]\(([^)]+)\)/g, (_, _l, url) => { mdLinks.push(url); return ' '; });

  const found = new Set();

  const add = (raw) => {
    if (!raw) return;
    let s = String(raw).trim();
    s = s.replace(/^<|>$/g, '').replace(/[.,);\]}'"`]+$/g, '');
    if (!s) return;
    found.add(s);
  };

  for (const u of mdLinks) add(u);

  // Full URLs with protocol
  const withProto = text.match(/https?:\/\/[^\s<>\[\]{}"']+/gi) || [];
  withProto.forEach(add);

  // www. domains
  const www = text.match(/\bwww\.[a-z0-9][-a-z0-9.]+\.[a-z]{2,}(?:\/[^\s<>\[\]{}"']*)?/gi) || [];
  www.forEach(add);

  // Bare domains: youtube.com, discord.gg/abc, youtu.be/xyz
  const bare = text.match(
    /\b(?:[a-z0-9](?:[-a-z0-9]*[a-z0-9])?\.)+(?:com|net|org|gg|io|co|uk|us|de|fr|ru|info|biz|tv|me|cc|app|dev|xyz|online|site|club|live|shop|blog|tech|store|art|pro|ai|to|ly|be|gl|page|link|click|zip|mov)(?:\/[^\s<>\[\]{}"']*)?/gi
  ) || [];
  bare.forEach(add);

  // IP-style http hosts
  const ips = text.match(/\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?(?:\/[^\s]*)?/g) || [];
  ips.forEach(add);

  return [...found];
}

function getHost(raw) {
  let s = String(raw).trim().toLowerCase();
  s = s.replace(/^https?:\/\//i, '').replace(/^www\./i, '');
  s = s.split('/')[0].split('?')[0].split('#')[0];
  s = s.replace(/:\d+$/, ''); // strip port
  return s;
}

function isDomainAllowed(host, allowedList) {
  if (!host) return false;
  return allowedList.some(d => {
    const dom = d.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];
    return host === dom || host.endsWith('.' + dom);
  });
}

function checkAntilink(message, cfg, content) {
  const rule = 'antilink';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  const r = cfg.rules.antilink;
  const links = extractLinks(content);
  if (!links.length) return null;

  const allowed = (r.allowedDomains || []).map(d =>
    d.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0]
  );
  if (r.allowDiscordLinks) {
    allowed.push(
      'discord.com', 'discord.gg', 'discordapp.com', 'discordapp.net',
      'cdn.discordapp.com', 'media.discordapp.net', 'discord.co'
    );
  }

  for (const raw of links) {
    const host = getHost(raw);
    // Skip pure numbers / empty
    if (!host || /^\d+$/.test(host)) continue;
    // Must look like a domain or IP
    if (!host.includes('.') && !/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) continue;

    if (!isDomainAllowed(host, allowed)) {
      return { rule, detail: `Blocked link: \`${host}\` (not in allowlist)` };
    }
  }
  return null;
}

function checkAntiinvite(message, cfg, content) {
  const rule = 'antiinvite';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  let text = content
    .replace(/\[(?:dot|\.)\]/gi, '.')
    .replace(/\(dot\)/gi, '.')
    .replace(/hxxps?:\/\//gi, 'http://');
  // discord.gg/xxx, discord.com/invite/xxx, discordapp.com/invite, discord.gg / xxx spaced
  const patterns = [
    /discord\.gg\s*\/\s*[a-z0-9-]+/i,
    /discord(?:app)?\.com\s*\/\s*invite\s*\/\s*[a-z0-9-]+/i,
    /discord\.new\s*\/\s*[a-z0-9-]+/i,
  ];
  if (patterns.some(re => re.test(text))) {
    return { rule, detail: 'Discord invite link detected' };
  }
  return null;
}

function checkCapsspam(message, cfg, content) {
  const rule = 'capsspam';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  const r = cfg.rules.capsspam;
  const letters = content.replace(/[^a-zA-Z]/g, '');
  if (letters.length < (r.minLength || 10)) return null;
  const upper = letters.replace(/[^A-Z]/g, '').length;
  const pct = (upper / letters.length) * 100;
  if (pct >= (r.maxPercent || 70)) return { rule, detail: `${Math.round(pct)}% caps` };
  return null;
}

function checkSpam(message, cfg) {
  const rule = 'spam';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  const r = cfg.rules.spam;
  const windowMs = (r.windowSeconds || 5) * 1000;
  const key = `${message.guild.id}:${message.author.id}:spam:${message.channel.id}`;
  const arr = trackPush(spamTracker, key, Date.now(), windowMs);
  if (arr.length > (r.maxMessages || 5)) return { rule, detail: `${arr.length} messages in ${r.windowSeconds}s` };
  return null;
}

function checkChannelspam(message, cfg) {
  const rule = 'channelspam';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  const r = cfg.rules.channelspam;
  const windowMs = (r.windowSeconds || 10) * 1000;
  const key = `${message.guild.id}:${message.author.id}:chspam`;
  const now = Date.now();
  let map = channelSpamTracker.get(key) || {};
  for (const [ch, ts] of Object.entries(map)) if (now - ts > windowMs) delete map[ch];
  map[message.channel.id] = now;
  channelSpamTracker.set(key, map);
  if (Object.keys(map).length > (r.maxChannels || 4)) {
    return { rule, detail: `Posted in ${Object.keys(map).length} channels` };
  }
  return null;
}

function checkMassmention(message, cfg) {
  const rule = 'massmention';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  if (message.mentions.users.size > (cfg.rules.massmention.maxMentions || 5)) {
    return { rule, detail: `${message.mentions.users.size} mentions` };
  }
  return null;
}

function checkEmojispam(message, cfg, content) {
  const rule = 'emojispam';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  const custom = (content.match(/<a?:\w+:\d+>/g) || []).length;
  const unicode = (content.match(/\p{Extended_Pictographic}/gu) || []).length;
  const total = custom + unicode;
  if (total > (cfg.rules.emojispam.maxEmojis || 8)) return { rule, detail: `${total} emojis` };
  return null;
}

function checkBadwords(message, cfg, content) {
  const rule = 'badwords';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  const r = cfg.rules.badwords;
  const words = r.words || [];
  if (!words.length) return null;
  const lower = content.toLowerCase();
  for (const w of words) {
    const word = String(w).toLowerCase().trim();
    if (!word) continue;
    if (r.matchPartial) {
      if (lower.includes(word)) return { rule, detail: 'Blocked word' };
    } else if (new RegExp(`\\b${escapeRegex(word)}\\b`, 'i').test(content)) {
      return { rule, detail: 'Blocked word' };
    }
  }
  return null;
}

function checkZalgo(message, cfg, content) {
  const rule = 'zalgo';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  const combining = (content.match(/[\u0300-\u036f\u0483-\u0489\u1ab0-\u1aff\u1dc0-\u1dff\u20d0-\u20ff\ufe20-\ufe2f]/g) || []).length;
  if (combining > (cfg.rules.zalgo.maxCombining || 6)) return { rule, detail: `Zalgo: ${combining}` };
  return null;
}

function checkDuplicates(message, cfg, content) {
  const rule = 'duplicates';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  if (!content.trim()) return null;
  const r = cfg.rules.duplicates;
  const windowMs = (r.windowSeconds || 30) * 1000;
  const key = `${message.guild.id}:${message.author.id}:dup`;
  const norm = content.trim().toLowerCase().replace(/\s+/g, ' ');
  const now = Date.now();
  let entry = dupTracker.get(key);
  if (!entry || entry.content !== norm) entry = { content: norm, times: [now] };
  else {
    entry.times = entry.times.filter(t => now - t < windowMs);
    entry.times.push(now);
  }
  dupTracker.set(key, entry);
  if (entry.times.length > (r.maxRepeats || 3)) return { rule, detail: `Repeated ${entry.times.length}x` };
  return null;
}

function checkNewlines(message, cfg, content) {
  const rule = 'newlines';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  const lines = (content.match(/\n/g) || []).length;
  if (lines > (cfg.rules.newlines.maxNewlines || 8)) return { rule, detail: `${lines} newlines` };
  return null;
}

function checkEveryone(message, cfg, content) {
  const rule = 'everyone';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  if (!content.includes('@everyone') && !content.includes('@here')) return null;
  if (message.member.permissions.has(PermissionFlagsBits.MentionEveryone)) return null;
  return { rule, detail: 'Unauthorized @everyone/@here' };
}

function checkAttachments(message, cfg) {
  const rule = 'attachments';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  const r = cfg.rules.attachments;
  if (message.attachments.size > (r.maxAttachments || 5)) {
    return { rule, detail: `${message.attachments.size} attachments` };
  }
  const blocked = (r.blockedExtensions || []).map(e => e.toLowerCase().replace('.', ''));
  for (const [, att] of message.attachments) {
    const name = (att.name || '').toLowerCase();
    const ext = name.includes('.') ? name.split('.').pop() : '';
    if (ext && blocked.includes(ext)) return { rule, detail: `Blocked .${ext}` };
  }
  return null;
}

function checkStickers(message, cfg) {
  const rule = 'stickers';
  if (!ruleEnabled(cfg, rule) || isRuleBypassed(message, cfg, rule)) return null;
  if (message.stickers.size > (cfg.rules.stickers.maxStickers || 3)) {
    return { rule, detail: `${message.stickers.size} stickers` };
  }
  return null;
}

async function enforce(message, cfg, rule, detail) {
  const storage = getStorage();
  const ruleCfg = cfg.rules[rule] || {};
  const action = (ruleCfg.action || cfg.defaultAction || 'warn').toLowerCase();
  const meta = RULE_META[rule] || { name: rule };

  if (cfg.deleteMessage !== false) await message.delete().catch(() => {});

  const guild = message.guild;
  const user = message.author;
  const member = message.member;
  let caseDoc = null;
  let actionNote = action;

  try {
    if (action === 'delete') actionNote = 'message deleted';
    else if (action === 'warn') {
      caseDoc = await storage.createCase({
        guildId: guild.id, userId: user.id, moderatorId: message.client.user.id,
        type: 'warn', reason: `Automod [${meta.name}]: ${detail}`, active: true, extra: { automodRule: rule },
      });
      await sendPunishmentDM(user, { type: 'warn', reason: `Automod [${meta.name}]: ${detail}`, caseId: caseDoc.caseId, guildName: guild.name, moderatorTag: 'Automod' });
    } else if (action === 'mute') {
      const durStr = ruleCfg.duration || cfg.defaultMuteDuration || '10m';
      let durationMs = parseDuration(durStr) || 600000;
      if (durationMs > 28 * 86400000) durationMs = 28 * 86400000;
      if (member?.moderatable) await member.timeout(durationMs, `Automod [${meta.name}]`).catch(() => {});
      const expiresAt = new Date(Date.now() + durationMs);
      caseDoc = await storage.createCase({
        guildId: guild.id, userId: user.id, moderatorId: message.client.user.id,
        type: 'mute', reason: `Automod [${meta.name}]: ${detail}`, duration: durationMs, expiresAt, active: true, extra: { automodRule: rule },
      });
      await sendPunishmentDM(user, { type: 'mute', reason: `Automod [${meta.name}]: ${detail}`, caseId: caseDoc.caseId, guildName: guild.name, moderatorTag: 'Automod', duration: durationMs, expiresAt });
      actionNote = `muted ${formatDuration(durationMs)}`;
    } else if (action === 'kick') {
      if (member?.kickable) await member.kick(`Automod [${meta.name}]`).catch(() => {});
      caseDoc = await storage.createCase({
        guildId: guild.id, userId: user.id, moderatorId: message.client.user.id,
        type: 'kick', reason: `Automod [${meta.name}]: ${detail}`, active: true, extra: { automodRule: rule },
      });
      actionNote = 'kicked';
    } else if (action === 'ban') {
      await guild.members.ban(user.id, { reason: `Automod [${meta.name}]: ${detail}`, deleteMessageSeconds: 0 }).catch(() => {});
      caseDoc = await storage.createCase({
        guildId: guild.id, userId: user.id, moderatorId: message.client.user.id,
        type: 'ban', reason: `Automod [${meta.name}]: ${detail}`, active: true, extra: { automodRule: rule },
      });
      await sendPunishmentDM(user, { type: 'ban', reason: `Automod [${meta.name}]: ${detail}`, caseId: caseDoc.caseId, guildName: guild.name, moderatorTag: 'Automod' });
      actionNote = 'banned';
    } else if (action === 'softban') {
      await guild.members.ban(user.id, { reason: `Automod softban`, deleteMessageSeconds: 86400 }).catch(() => {});
      await guild.members.unban(user.id, 'Automod softban').catch(() => {});
      caseDoc = await storage.createCase({
        guildId: guild.id, userId: user.id, moderatorId: message.client.user.id,
        type: 'softban', reason: `Automod [${meta.name}]: ${detail}`, active: true, extra: { automodRule: rule },
      });
      actionNote = 'softbanned';
    } else if (action === 'tempban') {
      const durStr = ruleCfg.duration || cfg.defaultTempbanDuration || '1d';
      const durationMs = parseDuration(durStr) || 86400000;
      await guild.members.ban(user.id, { reason: `Automod tempban`, deleteMessageSeconds: 0 }).catch(() => {});
      const expiresAt = new Date(Date.now() + durationMs);
      caseDoc = await storage.createCase({
        guildId: guild.id, userId: user.id, moderatorId: message.client.user.id,
        type: 'tempban', reason: `Automod [${meta.name}]: ${detail}`, duration: durationMs, expiresAt, active: true, extra: { automodRule: rule },
      });
      await sendPunishmentDM(user, { type: 'tempban', reason: `Automod [${meta.name}]: ${detail}`, caseId: caseDoc.caseId, guildName: guild.name, moderatorTag: 'Automod', duration: durationMs, expiresAt });
      actionNote = `tempbanned ${formatDuration(durationMs)}`;
    }
  } catch (err) {
    console.error('[Automod] enforce:', err.message);
  }

  if (cfg.logChannelId) {
    try {
      const ch = await guild.channels.fetch(cfg.logChannelId).catch(() => null);
      if (ch?.isTextBased()) {
        await ch.send({
          embeds: [
            new EmbedBuilder()
              .setColor(0xe74c3c)
              .setTitle(`Automod — ${meta.name}`)
              .addFields(
                { name: 'User', value: `${user} (\`${user.id}\`)`, inline: true },
                { name: 'Channel', value: `${message.channel}`, inline: true },
                { name: 'Action', value: actionNote, inline: true },
                { name: 'Detail', value: detail || '—' },
                { name: 'Content', value: (message.content || '[media]').slice(0, 500) || '—' },
              )
              .setTimestamp(),
          ],
        });
      }
    } catch (_) {}
  }
}

async function handleMessage(message) {
  if (!message.guild || !message.member) return;
  if (message.author.bot) return;
  if (!message.content && !message.attachments.size && !message.stickers.size) return;

  const { cfg } = await loadCfg(message.guild.id);
  if (!cfg.enabled) return;
  if (cfg.ignoreAdmins && message.member.permissions.has(PermissionFlagsBits.Administrator)) return;
  if (cfg.ignoredChannels.includes(message.channel.id)) return;
  if (message.member.roles.cache.some(r => cfg.ignoredRoles.includes(r.id))) return;

  const content = message.content || '';
  const checks = [
    () => checkAntilink(message, cfg, content),
    () => checkAntiinvite(message, cfg, content),
    () => checkCapsspam(message, cfg, content),
    () => checkSpam(message, cfg),
    () => checkChannelspam(message, cfg),
    () => checkMassmention(message, cfg),
    () => checkEmojispam(message, cfg, content),
    () => checkBadwords(message, cfg, content),
    () => checkZalgo(message, cfg, content),
    () => checkDuplicates(message, cfg, content),
    () => checkNewlines(message, cfg, content),
    () => checkEveryone(message, cfg, content),
    () => checkAttachments(message, cfg),
    () => checkStickers(message, cfg),
  ];
  for (const check of checks) {
    const hit = check();
    if (hit) {
      await enforce(message, cfg, hit.rule, hit.detail);
      return;
    }
  }
}

// ─── Panel interaction loop ──────────────────────────────────

async function runPanel(interaction) {
  const guildId = interaction.guild.id;
  let { cfg } = await loadCfg(guildId);

  const payload = () => ({
    embeds: [mainEmbed(cfg, interaction.guild)],
    components: mainComponents(cfg),
  });

  const msg = await interaction.reply({ ...payload(), ephemeral: true, fetchReply: true });

  const collector = msg.createMessageComponentCollector({
    filter: i => i.user.id === interaction.user.id,
    time: 10 * 60 * 1000,
  });

  collector.on('collect', async (i) => {
    try {
      const id = i.customId;
      ({ cfg } = await loadCfg(guildId));

      // ── Home / refresh / toggle ──
      if (id === 'am:home' || id === 'am:refresh') {
        ({ cfg } = await loadCfg(guildId));
        return i.update({ embeds: [mainEmbed(cfg, interaction.guild)], components: mainComponents(cfg) });
      }
      if (id === 'am:toggle') {
        cfg.enabled = !cfg.enabled;
        await saveCfg(guildId, cfg);
        return i.update({ embeds: [mainEmbed(cfg, interaction.guild)], components: mainComponents(cfg) });
      }

      // ── Set log channel ──
      if (id === 'am:log') {
        const row = new ActionRowBuilder().addComponents(
          new ChannelSelectMenuBuilder()
            .setCustomId('am:logpick')
            .setPlaceholder('Select log channel…')
            .addChannelTypes(ChannelType.GuildText)
            .setMinValues(1)
            .setMaxValues(1)
        );
        return i.update({
          embeds: [new EmbedBuilder().setColor(0x3498db).setTitle('Set AutoMod Log Channel').setDescription('Pick a text channel below.')],
          components: [row, new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('am:home').setLabel('Cancel').setStyle(ButtonStyle.Secondary)
          )],
        });
      }
      if (id === 'am:logpick' && i.isChannelSelectMenu()) {
        cfg.logChannelId = i.values[0];
        await saveCfg(guildId, cfg);
        return i.update({ embeds: [mainEmbed(cfg, interaction.guild)], components: mainComponents(cfg) });
      }

      // ── Defaults ──
      if (id === 'am:defaults') {
        const row = new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId('am:defaultaction')
            .setPlaceholder(`Default action (current: ${cfg.defaultAction})`)
            .addOptions(ACTIONS.map(a => ({ label: a, value: a })))
        );
        const row2 = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('am:defmute').setLabel('Mute duration').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('am:deftemp').setLabel('Tempban duration').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('am:defdel')
            .setLabel(cfg.deleteMessage ? 'Delete msgs: ON' : 'Delete msgs: OFF')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('am:home').setLabel('Back').setStyle(ButtonStyle.Primary),
        );
        return i.update({
          embeds: [new EmbedBuilder().setColor(0x9b59b6).setTitle('Defaults')
            .setDescription(`Action: **${cfg.defaultAction}**\nMute: **${cfg.defaultMuteDuration}**\nTempban: **${cfg.defaultTempbanDuration}**\nDelete messages: **${cfg.deleteMessage}**`)],
          components: [row, row2],
        });
      }
      if (id === 'am:defaultaction' && i.isStringSelectMenu()) {
        cfg.defaultAction = i.values[0];
        await saveCfg(guildId, cfg);
        return i.update({
          embeds: [new EmbedBuilder().setColor(0x9b59b6).setTitle('Defaults').setDescription(`Default action set to **${cfg.defaultAction}**`)],
          components: mainComponents(cfg),
        });
      }
      if (id === 'am:defdel') {
        cfg.deleteMessage = !cfg.deleteMessage;
        await saveCfg(guildId, cfg);
        return i.update({ embeds: [mainEmbed(cfg, interaction.guild)], components: mainComponents(cfg) });
      }
      if (id === 'am:defmute' || id === 'am:deftemp') {
        const which = id === 'am:defmute' ? 'mute' : 'tempban';
        const modal = new ModalBuilder()
          .setCustomId(`am:modal:${which}dur`)
          .setTitle(`Default ${which} duration`);
        modal.addComponents(new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('duration')
            .setLabel('Duration (e.g. 10m, 1h, 1d)')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setValue(which === 'mute' ? cfg.defaultMuteDuration : cfg.defaultTempbanDuration)
        ));
        await i.showModal(modal);
        try {
          const sub = await i.awaitModalSubmit({ time: 120000, filter: m => m.user.id === interaction.user.id });
          const val = sub.fields.getTextInputValue('duration');
          if (!parseDuration(val)) {
            return sub.reply({ content: 'Invalid duration.', ephemeral: true });
          }
          ({ cfg } = await loadCfg(guildId));
          if (which === 'mute') cfg.defaultMuteDuration = val;
          else cfg.defaultTempbanDuration = val;
          await saveCfg(guildId, cfg);
          return sub.reply({ content: `Default ${which} duration → **${val}**`, ephemeral: true });
        } catch (_) {}
        return;
      }

      // ── Rules list ──
      if (id === 'am:rules') {
        return i.update({
          embeds: [new EmbedBuilder().setColor(0x3498db).setTitle('Configure Rules').setDescription('Pick a rule from the menu.')],
          components: [rulesSelectRow(), new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('am:home').setLabel('Back').setStyle(ButtonStyle.Secondary)
          )],
        });
      }
      if (id === 'am:rulepick' && i.isStringSelectMenu()) {
        const ruleKey = i.values[0];
        ({ cfg } = await loadCfg(guildId));
        return i.update({ embeds: [ruleEmbed(cfg, ruleKey)], components: ruleComponents(ruleKey, cfg) });
      }

      // ── Per-rule actions ──
      if (id.startsWith('am:ruletoggle:')) {
        const ruleKey = id.split(':')[2];
        cfg.rules[ruleKey] = cfg.rules[ruleKey] || {};
        cfg.rules[ruleKey].enabled = !cfg.rules[ruleKey].enabled;
        await saveCfg(guildId, cfg);
        return i.update({ embeds: [ruleEmbed(cfg, ruleKey)], components: ruleComponents(ruleKey, cfg) });
      }
      if (id.startsWith('am:ruleaction:')) {
        const ruleKey = id.split(':')[2];
        return i.update({
          embeds: [ruleEmbed(cfg, ruleKey)],
          components: [actionSelectRow(ruleKey), new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`am:ruleback:${ruleKey}`).setLabel('Back').setStyle(ButtonStyle.Secondary)
          )],
        });
      }
      if (id.startsWith('am:setaction:') && i.isStringSelectMenu()) {
        const ruleKey = id.split(':')[2];
        cfg.rules[ruleKey] = cfg.rules[ruleKey] || {};
        cfg.rules[ruleKey].action = i.values[0];
        await saveCfg(guildId, cfg);
        return i.update({ embeds: [ruleEmbed(cfg, ruleKey)], components: ruleComponents(ruleKey, cfg) });
      }
      if (id.startsWith('am:ruleback:')) {
        const ruleKey = id.split(':')[2];
        return i.update({ embeds: [ruleEmbed(cfg, ruleKey)], components: ruleComponents(ruleKey, cfg) });
      }
      if (id.startsWith('am:ruleduration:')) {
        const ruleKey = id.split(':')[2];
        const modal = new ModalBuilder().setCustomId(`am:modal:dur:${ruleKey}`).setTitle('Rule duration (mute/tempban)');
        modal.addComponents(new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('duration')
            .setLabel('Duration (e.g. 10m, 1h) or empty for default')
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setValue(cfg.rules[ruleKey]?.duration || '')
        ));
        await i.showModal(modal);
        try {
          const sub = await i.awaitModalSubmit({ time: 120000, filter: m => m.user.id === interaction.user.id });
          const val = sub.fields.getTextInputValue('duration').trim();
          if (val && !parseDuration(val)) return sub.reply({ content: 'Invalid duration.', ephemeral: true });
          ({ cfg } = await loadCfg(guildId));
          cfg.rules[ruleKey] = cfg.rules[ruleKey] || {};
          cfg.rules[ruleKey].duration = val || null;
          await saveCfg(guildId, cfg);
          return sub.reply({ content: `Duration for **${RULE_META[ruleKey].name}** → **${val || 'default'}**`, ephemeral: true });
        } catch (_) {}
        return;
      }
      if (id.startsWith('am:rulediscord:')) {
        const ruleKey = 'antilink';
        cfg.rules.antilink = cfg.rules.antilink || {};
        cfg.rules.antilink.allowDiscordLinks = !cfg.rules.antilink.allowDiscordLinks;
        await saveCfg(guildId, cfg);
        return i.update({ embeds: [ruleEmbed(cfg, ruleKey)], components: ruleComponents(ruleKey, cfg) });
      }
      if (id.startsWith('am:rulethresh:')) {
        const ruleKey = id.split(':')[2];
        const r = cfg.rules[ruleKey] || {};
        const modal = new ModalBuilder().setCustomId(`am:modal:thresh:${ruleKey}`).setTitle(`Thresholds: ${RULE_META[ruleKey]?.name || ruleKey}`);
        // generic two fields depending on rule
        const inputs = [];
        if (ruleKey === 'spam' || ruleKey === 'channelspam' || ruleKey === 'duplicates') {
          inputs.push(
            new TextInputBuilder().setCustomId('a').setLabel(ruleKey === 'channelspam' ? 'Max channels' : ruleKey === 'duplicates' ? 'Max repeats' : 'Max messages').setStyle(TextInputStyle.Short).setRequired(false)
              .setValue(String(r.maxMessages || r.maxChannels || r.maxRepeats || '')),
            new TextInputBuilder().setCustomId('b').setLabel('Window seconds').setStyle(TextInputStyle.Short).setRequired(false)
              .setValue(String(r.windowSeconds || '')),
          );
        } else if (ruleKey === 'capsspam') {
          inputs.push(
            new TextInputBuilder().setCustomId('a').setLabel('Max % caps').setStyle(TextInputStyle.Short).setRequired(false).setValue(String(r.maxPercent || '')),
            new TextInputBuilder().setCustomId('b').setLabel('Min letter length').setStyle(TextInputStyle.Short).setRequired(false).setValue(String(r.minLength || '')),
          );
        } else if (ruleKey === 'massmention' || ruleKey === 'emojispam' || ruleKey === 'newlines' || ruleKey === 'stickers' || ruleKey === 'attachments' || ruleKey === 'zalgo') {
          const label = {
            massmention: 'Max mentions', emojispam: 'Max emojis', newlines: 'Max newlines',
            stickers: 'Max stickers', attachments: 'Max attachments', zalgo: 'Max combining chars',
          }[ruleKey];
          const val = r.maxMentions || r.maxEmojis || r.maxNewlines || r.maxStickers || r.maxAttachments || r.maxCombining || '';
          inputs.push(new TextInputBuilder().setCustomId('a').setLabel(label).setStyle(TextInputStyle.Short).setRequired(false).setValue(String(val)));
        } else {
          inputs.push(new TextInputBuilder().setCustomId('a').setLabel('Value (optional)').setStyle(TextInputStyle.Short).setRequired(false));
        }
        for (const inp of inputs) modal.addComponents(new ActionRowBuilder().addComponents(inp));
        await i.showModal(modal);
        try {
          const sub = await i.awaitModalSubmit({ time: 120000, filter: m => m.user.id === interaction.user.id });
          ({ cfg } = await loadCfg(guildId));
          cfg.rules[ruleKey] = cfg.rules[ruleKey] || {};
          const a = sub.fields.getTextInputValue('a')?.trim();
          let b = '';
          try { b = sub.fields.getTextInputValue('b')?.trim(); } catch (_) {}
          const num = v => (v && !isNaN(Number(v)) ? Number(v) : null);
          if (ruleKey === 'spam') {
            if (num(a) != null) cfg.rules[ruleKey].maxMessages = num(a);
            if (num(b) != null) cfg.rules[ruleKey].windowSeconds = num(b);
          } else if (ruleKey === 'channelspam') {
            if (num(a) != null) cfg.rules[ruleKey].maxChannels = num(a);
            if (num(b) != null) cfg.rules[ruleKey].windowSeconds = num(b);
          } else if (ruleKey === 'duplicates') {
            if (num(a) != null) cfg.rules[ruleKey].maxRepeats = num(a);
            if (num(b) != null) cfg.rules[ruleKey].windowSeconds = num(b);
          } else if (ruleKey === 'capsspam') {
            if (num(a) != null) cfg.rules[ruleKey].maxPercent = num(a);
            if (num(b) != null) cfg.rules[ruleKey].minLength = num(b);
          } else if (ruleKey === 'massmention' && num(a) != null) cfg.rules[ruleKey].maxMentions = num(a);
          else if (ruleKey === 'emojispam' && num(a) != null) cfg.rules[ruleKey].maxEmojis = num(a);
          else if (ruleKey === 'newlines' && num(a) != null) cfg.rules[ruleKey].maxNewlines = num(a);
          else if (ruleKey === 'stickers' && num(a) != null) cfg.rules[ruleKey].maxStickers = num(a);
          else if (ruleKey === 'attachments' && num(a) != null) cfg.rules[ruleKey].maxAttachments = num(a);
          else if (ruleKey === 'zalgo' && num(a) != null) cfg.rules[ruleKey].maxCombining = num(a);
          await saveCfg(guildId, cfg);
          return sub.reply({ content: `Thresholds updated for **${RULE_META[ruleKey].name}**.`, ephemeral: true });
        } catch (_) {}
        return;
      }

      // ── Allowed domains (antilink allowlist) ──
      if (id === 'am:domains') {
        const list = cfg.rules.antilink?.allowedDomains || [];
        const modal = new ModalBuilder().setCustomId('am:modal:domains').setTitle('Allowed link domains');
        modal.addComponents(new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('domains')
            .setLabel('Domains (comma-separated). Empty = block all')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
            .setValue(list.join(', '))
            .setPlaceholder('youtube.com, tenor.com, giphy.com')
        ));
        await i.showModal(modal);
        try {
          const sub = await i.awaitModalSubmit({ time: 120000, filter: m => m.user.id === interaction.user.id });
          const raw = sub.fields.getTextInputValue('domains') || '';
          const domains = raw.split(/[\s,]+/).map(s => s.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '')).filter(Boolean);
          ({ cfg } = await loadCfg(guildId));
          cfg.rules.antilink = cfg.rules.antilink || {};
          cfg.rules.antilink.allowedDomains = domains;
          await saveCfg(guildId, cfg);
          return sub.reply({
            content: domains.length
              ? `Allowed domains (${domains.length}): ${domains.map(d => `\`${d}\``).join(', ')}\nAll other links are **blocked**.`
              : 'Allowlist empty — **all links are blocked**.',
            ephemeral: true,
          });
        } catch (_) {}
        return;
      }

      // ── Bad words ──
      if (id === 'am:words') {
        const list = cfg.rules.badwords?.words || [];
        const modal = new ModalBuilder().setCustomId('am:modal:words').setTitle('Bad words list');
        modal.addComponents(new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('words')
            .setLabel('Words (comma-separated)')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
            .setValue(list.join(', '))
        ));
        await i.showModal(modal);
        try {
          const sub = await i.awaitModalSubmit({ time: 120000, filter: m => m.user.id === interaction.user.id });
          const words = (sub.fields.getTextInputValue('words') || '')
            .split(',')
            .map(s => s.trim().toLowerCase())
            .filter(Boolean);
          ({ cfg } = await loadCfg(guildId));
          cfg.rules.badwords = cfg.rules.badwords || {};
          cfg.rules.badwords.words = words;
          await saveCfg(guildId, cfg);
          return sub.reply({ content: `Bad words updated (${words.length}).`, ephemeral: true });
        } catch (_) {}
        return;
      }

      // ── Bypasses ──
      if (id === 'am:bypass') {
        return i.update({
          embeds: [new EmbedBuilder().setColor(0xf1c40f).setTitle('Global Bypasses')
            .setDescription(
              `**Channels:** ${(cfg.ignoredChannels || []).map(c => `<#${c}>`).join(' ') || 'none'}\n` +
              `**Roles:** ${(cfg.ignoredRoles || []).map(r => `<@&${r}>`).join(' ') || 'none'}\n\n` +
              'Select channels/roles to **set** the bypass list (replaces current).'
            )],
          components: [
            new ActionRowBuilder().addComponents(
              new ChannelSelectMenuBuilder()
                .setCustomId('am:bypassch')
                .setPlaceholder('Bypass channels…')
                .addChannelTypes(ChannelType.GuildText)
                .setMinValues(0)
                .setMaxValues(25)
            ),
            new ActionRowBuilder().addComponents(
              new RoleSelectMenuBuilder()
                .setCustomId('am:bypassrole')
                .setPlaceholder('Bypass roles…')
                .setMinValues(0)
                .setMaxValues(25)
            ),
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('am:bypassclear').setLabel('Clear all bypasses').setStyle(ButtonStyle.Danger),
              new ButtonBuilder().setCustomId('am:home').setLabel('Back').setStyle(ButtonStyle.Secondary),
            ),
          ],
        });
      }
      if (id === 'am:bypassch' && i.isChannelSelectMenu()) {
        cfg.ignoredChannels = [...i.values];
        await saveCfg(guildId, cfg);
        return i.update({ embeds: [mainEmbed(cfg, interaction.guild)], components: mainComponents(cfg) });
      }
      if (id === 'am:bypassrole' && i.isRoleSelectMenu()) {
        cfg.ignoredRoles = [...i.values];
        await saveCfg(guildId, cfg);
        return i.update({ embeds: [mainEmbed(cfg, interaction.guild)], components: mainComponents(cfg) });
      }
      if (id === 'am:bypassclear') {
        cfg.ignoredChannels = [];
        cfg.ignoredRoles = [];
        await saveCfg(guildId, cfg);
        return i.update({ embeds: [mainEmbed(cfg, interaction.guild)], components: mainComponents(cfg) });
      }
    } catch (err) {
      console.error('[Automod panel]', err);
      if (!i.replied && !i.deferred) {
        await i.reply({ content: `Error: ${err.message}`, ephemeral: true }).catch(() => {});
      }
    }
  });

  collector.on('end', async () => {
    try {
      await interaction.editReply({
        components: [],
        content: 'Panel expired — run `/automod` again.',
      }).catch(() => {});
    } catch (_) {}
  });
}

// ─── Slash command ───────────────────────────────────────────

module.exports = {
  handleMessage,

  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Open the AutoMod control panel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    if (!(await canManage(interaction.member))) {
      return interaction.reply({ content: 'You do not have permission to manage AutoMod.', ephemeral: true });
    }
    return runPanel(interaction);
  },
};
