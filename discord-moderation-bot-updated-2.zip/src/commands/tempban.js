const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const { sendPunishmentDM } = require('../utils/dm');
const { parseDuration, formatDuration } = require('../utils/duration');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tempban')
    .setDescription('Temporary ban management')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Temporarily ban a user')
        .addUserOption(o => o.setName('user').setDescription('User to tempban').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(true))
        .addStringOption(o => o.setName('duration').setDescription('Duration (e.g. 1h, 2d, 1w)').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a temporary ban early')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('edit')
        .setDescription('Edit reason or duration of a tempban')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('New reason').setRequired(true))
        .addStringOption(o => o.setName('duration').setDescription('New duration (e.g. 1h, 2d)').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List all temporary bans (50 per page)')
        .addIntegerOption(o =>
          o.setName('page').setDescription('Page number').setMinValue(1)
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const guild = interaction.guild;
    const moderator = interaction.user;

    const cmdKey = `tempban.${sub}`;
    if (!(await canRunCommand(interaction.member, cmdKey))) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }

    if (sub === 'add') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);
      const durationStr = interaction.options.getString('duration', true);
      const durationMs = parseDuration(durationStr);

      if (!durationMs) {
        return interaction.reply({
          content: 'Invalid duration. Use formats like `30m`, `2h`, `1d`, `1w`.',
          ephemeral: true,
        });
      }

      if (user.id === interaction.client.user.id || user.id === moderator.id) {
        return interaction.reply({ content: 'Cannot tempban yourself or the bot.', ephemeral: true });
      }

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (member && !member.bannable) {
        return interaction.reply({ content: 'I cannot ban this user.', ephemeral: true });
      }

      const existing = await storage.findActiveByUser(guild.id, user.id, 'tempban');
      if (existing) {
        return interaction.reply({
          content: `User already has an active tempban (Case #${existing.caseId}).`,
          ephemeral: true,
        });
      }

      await interaction.deferReply();

      try {
        await guild.members.ban(user.id, { reason: `[Tempban by ${moderator.tag}] ${reason}`, deleteMessageSeconds: 0 });
      } catch (err) {
        return interaction.editReply({ content: `Failed to ban: ${err.message}` });
      }

      const expiresAt = new Date(Date.now() + durationMs);
      const caseDoc = await storage.createCase({
        guildId: guild.id,
        userId: user.id,
        moderatorId: moderator.id,
        type: 'tempban',
        reason,
        duration: durationMs,
        expiresAt,
        active: true,
      });

      const dmSent = await sendPunishmentDM(user, {
        type: 'tempban',
        reason,
        caseId: caseDoc.caseId,
        guildName: guild.name,
        moderatorTag: moderator.tag,
        duration: durationMs,
        expiresAt,
      });

      const embed = new EmbedBuilder()
        .setColor(0xe67e22)
        .setTitle('User Temporarily Banned')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Case ID', value: `#${caseDoc.caseId}`, inline: true },
          { name: 'Duration', value: formatDuration(durationMs), inline: true },
          { name: 'Expires', value: `<t:${Math.floor(expiresAt.getTime() / 1000)}:R>`, inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
          { name: 'Reason', value: reason },
          { name: 'DM Sent', value: dmSent ? 'Yes' : 'No', inline: true },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);

      await interaction.deferReply();

      const active = await storage.findActiveByUser(guild.id, user.id, 'tempban');
      if (!active) {
        try {
          await guild.members.unban(user.id, `[${moderator.tag}] ${reason}`);
        } catch (_) {}
        return interaction.editReply({ content: 'No active tempban found (attempted unban).' });
      }

      try {
        await guild.members.unban(user.id, `[${moderator.tag}] ${reason}`);
      } catch (_) {}

      await storage.deactivateCase(guild.id, active.caseId);

      const embed = new EmbedBuilder()
        .setColor(0x2ecc71)
        .setTitle('Tempban Removed')
        .addFields(
          { name: 'User', value: `${user.tag}`, inline: true },
          { name: 'Case ID', value: `#${active.caseId}`, inline: true },
          { name: 'Reason', value: reason },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'edit') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);
      const durationStr = interaction.options.getString('duration', true);
      const durationMs = parseDuration(durationStr);

      if (!durationMs) {
        return interaction.reply({ content: 'Invalid duration.', ephemeral: true });
      }

      const active = await storage.findActiveByUser(guild.id, user.id, 'tempban');
      if (!active) {
        return interaction.reply({ content: 'No active tempban for this user.', ephemeral: true });
      }

      const expiresAt = new Date(Date.now() + durationMs);
      await storage.updateCase(guild.id, active.caseId, {
        reason,
        duration: durationMs,
        expiresAt,
      });

      return interaction.reply({
        content: `Updated tempban Case #${active.caseId}: reason **${reason}**, duration **${formatDuration(durationMs)}** (expires <t:${Math.floor(expiresAt.getTime() / 1000)}:R>)`,
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const page = interaction.options.getInteger('page') || 1;
      const result = await storage.getActiveCases(guild.id, 'tempban', page, config.pageSize);

      if (result.total === 0) {
        return interaction.reply({ content: 'No active temporary bans.', ephemeral: true });
      }

      const lines = result.items.map(c => {
        const exp = c.expiresAt
          ? `<t:${Math.floor(new Date(c.expiresAt).getTime() / 1000)}:R>`
          : 'unknown';
        return `**#${c.caseId}** <@${c.userId}> — ${c.reason.slice(0, 40)}… (expires ${exp})`;
      });

      const embed = new EmbedBuilder()
        .setColor(0xe67e22)
        .setTitle(`Active Tempbans — Page ${result.page}/${result.totalPages}`)
        .setDescription(lines.join('\n'))
        .setFooter({ text: `Total: ${result.total}` });

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
