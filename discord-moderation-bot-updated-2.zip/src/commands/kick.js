const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const { sendPunishmentDM } = require('../utils/dm');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick management commands')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Kick a user')
        .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason for the kick').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('edit')
        .setDescription('Edit the reason of a kick case')
        .addUserOption(o => o.setName('user').setDescription('Kicked user').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('New reason').setRequired(true))
        .addIntegerOption(o =>
          o.setName('case_id').setDescription('Specific case ID to edit (latest if omitted)')
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List kick records (50 per page)')
        .addIntegerOption(o =>
          o.setName('page').setDescription('Page number').setMinValue(1)
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const guild = interaction.guild;
    const moderator = interaction.user;

    const cmdKey = `kick.${sub}`;
    if (!(await canRunCommand(interaction.member, cmdKey))) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }

    if (sub === 'add') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);

      if (user.id === interaction.client.user.id) {
        return interaction.reply({ content: 'I cannot kick myself.', ephemeral: true });
      }
      if (user.id === moderator.id) {
        return interaction.reply({ content: 'You cannot kick yourself.', ephemeral: true });
      }

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (!member) {
        return interaction.reply({
          content: 'That user is not in this server.',
          ephemeral: true,
        });
      }
      if (!member.kickable) {
        return interaction.reply({
          content: 'I cannot kick this user (higher role or missing permissions).',
          ephemeral: true,
        });
      }

      await interaction.deferReply();

      try {
        await member.kick(`[${moderator.tag}] ${reason}`);
      } catch (err) {
        return interaction.editReply({ content: `Failed to kick: ${err.message}` });
      }

      const caseDoc = await storage.createCase({
        guildId: guild.id,
        userId: user.id,
        moderatorId: moderator.id,
        type: 'kick',
        reason,
        active: true,
      });

      const dmSent = await sendPunishmentDM(user, {
        type: 'kick',
        reason,
        caseId: caseDoc.caseId,
        guildName: guild.name,
        moderatorTag: moderator.tag,
      });

      const embed = new EmbedBuilder()
        .setColor(0xe67e22)
        .setTitle('User Kicked')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Case ID', value: `#${caseDoc.caseId}`, inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
          { name: 'Reason', value: reason },
          { name: 'DM Sent', value: dmSent ? 'Yes' : 'No (DMs closed)', inline: true },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'edit') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);
      const caseIdOpt = interaction.options.getInteger('case_id');

      let targetCase;
      if (caseIdOpt) {
        targetCase = await storage.getCase(guild.id, caseIdOpt);
        if (!targetCase || targetCase.userId !== user.id || targetCase.type !== 'kick') {
          return interaction.reply({
            content: 'Case not found or does not belong to this user/type.',
            ephemeral: true,
          });
        }
      } else {
        const cases = await storage.getCasesByUser(guild.id, user.id, 'kick', true);
        targetCase = cases[0];
        if (!targetCase) {
          return interaction.reply({
            content: 'No kick case found for this user.',
            ephemeral: true,
          });
        }
      }

      await storage.updateCase(guild.id, targetCase.caseId, { reason });

      return interaction.reply({
        content: `Updated kick Case #${targetCase.caseId} reason to: **${reason}**`,
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const page = interaction.options.getInteger('page') || 1;
      const result = await storage.getActiveCases(guild.id, 'kick', page, config.pageSize);

      if (result.total === 0) {
        return interaction.reply({ content: 'No kick records.', ephemeral: true });
      }

      const lines = result.items.map(c => {
        const date = new Date(c.createdAt).toLocaleDateString();
        return `**#${c.caseId}** <@${c.userId}> — ${c.reason.slice(0, 60)}${c.reason.length > 60 ? '…' : ''} (${date})`;
      });

      const embed = new EmbedBuilder()
        .setColor(0xe67e22)
        .setTitle(`Kicks — Page ${result.page}/${result.totalPages}`)
        .setDescription(lines.join('\n') || 'None')
        .setFooter({ text: `Total: ${result.total}` });

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
