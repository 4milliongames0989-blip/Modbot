const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const { sendPunishmentDM } = require('../utils/dm');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn management commands')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Warn a user')
        .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason for the warn').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('edit')
        .setDescription('Edit the reason of a warn case')
        .addUserOption(o => o.setName('user').setDescription('Warned user').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('New reason').setRequired(true))
        .addIntegerOption(o => o.setName('case_id').setDescription('Specific case ID to edit (latest if omitted)'))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a warn from a user')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason for removal').setRequired(true))
        .addIntegerOption(o => o.setName('case_id').setDescription('Specific case ID to remove (latest active if omitted)'))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const guild = interaction.guild;
    const moderator = interaction.user;

    const cmdKey = `warn.${sub}`;
    if (!(await canRunCommand(interaction.member, cmdKey))) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }

    if (sub === 'add') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);

      await interaction.deferReply();

      const caseDoc = await storage.createCase({
        guildId: guild.id,
        userId: user.id,
        moderatorId: moderator.id,
        type: 'warn',
        reason,
        active: true,
      });

      const dmSent = await sendPunishmentDM(user, {
        type: 'warn',
        reason,
        caseId: caseDoc.caseId,
        guildName: guild.name,
        moderatorTag: moderator.tag,
      });

      const allWarns = await storage.getCasesByUser(guild.id, user.id, 'warn', true);

      const embed = new EmbedBuilder()
        .setColor(0xf1c40f)
        .setTitle('User Warned')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Case ID', value: `#${caseDoc.caseId}`, inline: true },
          { name: 'Active Warns', value: String(allWarns.length), inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
          { name: 'Reason', value: reason },
          { name: 'DM Sent', value: dmSent ? 'Yes' : 'No (DMs closed)', inline: true },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'edit') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);
      const caseIdOpt = interaction.options.getInteger('case_id');

      let targetCase;
      if (caseIdOpt) {
        targetCase = await storage.getCase(guild.id, caseIdOpt);
        if (!targetCase || targetCase.userId !== user.id || targetCase.type !== 'warn') {
          return interaction.reply({ content: 'Case not found or does not belong to this user/type.', ephemeral: true });
        }
      } else {
        const cases = await storage.getCasesByUser(guild.id, user.id, 'warn', true);
        targetCase = cases[0];
        if (!targetCase) {
          return interaction.reply({ content: 'No active warn found for this user.', ephemeral: true });
        }
      }

      await storage.updateCase(guild.id, targetCase.caseId, { reason });

      return interaction.reply({
        content: `Updated warn Case #${targetCase.caseId} reason to: **${reason}**`,
        ephemeral: true,
      });
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);
      const caseIdOpt = interaction.options.getInteger('case_id');

      let targetCase;
      if (caseIdOpt) {
        targetCase = await storage.getCase(guild.id, caseIdOpt);
        if (!targetCase || targetCase.userId !== user.id || targetCase.type !== 'warn' || !targetCase.active) {
          return interaction.reply({ content: 'Active warn case not found for this user.', ephemeral: true });
        }
      } else {
        const cases = await storage.getCasesByUser(guild.id, user.id, 'warn', true);
        targetCase = cases[0];
        if (!targetCase) {
          return interaction.reply({ content: 'No active warn found for this user.', ephemeral: true });
        }
      }

      await storage.deactivateCase(guild.id, targetCase.caseId);

      return interaction.reply({
        content: `Removed warn Case #${targetCase.caseId} from ${user.tag}. Reason: ${reason}`,
        ephemeral: true,
      });
    }
  },
};
