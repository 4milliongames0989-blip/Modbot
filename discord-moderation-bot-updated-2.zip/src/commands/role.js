const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const { parseDuration, formatDuration } = require('../utils/duration');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('role')
    .setDescription('Role management commands')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Add a role to a user')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addRoleOption(o => o.setName('role').setDescription('Role to add').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a role from a user')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addRoleOption(o => o.setName('role').setDescription('Role to remove').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('temp')
        .setDescription('Temporarily give a user a role')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addRoleOption(o => o.setName('role').setDescription('Role to give temporarily').setRequired(true))
        .addStringOption(o =>
          o.setName('duration').setDescription('Duration (e.g. 30s, 10m, 2h, 1d)').setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('info')
        .setDescription('Show info about a role')
        .addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true))
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const guild = interaction.guild;
    const moderator = interaction.user;

    const cmdKey = `role.${sub}`;
    if (!(await canRunCommand(interaction.member, cmdKey))) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }

    // ── role add ──────────────────────────────────────────────
    if (sub === 'add') {
      const user = interaction.options.getUser('user', true);
      const role = interaction.options.getRole('role', true);

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (!member) {
        return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
      }

      if (role.managed) {
        return interaction.reply({ content: 'I cannot assign managed roles (bot/integration roles).', ephemeral: true });
      }
      if (role.position >= guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'That role is higher than or equal to my highest role.', ephemeral: true });
      }
      if (member.roles.cache.has(role.id)) {
        return interaction.reply({ content: `${user.tag} already has **${role.name}**.`, ephemeral: true });
      }

      await interaction.deferReply();

      try {
        await member.roles.add(role, `[Role add by ${moderator.tag}]`);
      } catch (err) {
        return interaction.editReply({ content: `Failed to add role: ${err.message}` });
      }

      const caseDoc = await storage.createCase({
        guildId: guild.id,
        userId: user.id,
        moderatorId: moderator.id,
        type: 'role',
        reason: `Added role ${role.name}`,
        active: true,
        extra: { roleId: role.id, action: 'add' },
      });

      const embed = new EmbedBuilder()
        .setColor(role.color || 0x2ecc71)
        .setTitle('Role Added')
        .addFields(
          { name: 'User', value: `${user.tag}`, inline: true },
          { name: 'Role', value: `${role}`, inline: true },
          { name: 'Case ID', value: `#${caseDoc.caseId}`, inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    // ── role remove ───────────────────────────────────────────
    if (sub === 'remove') {
      const user = interaction.options.getUser('user', true);
      const role = interaction.options.getRole('role', true);

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (!member) {
        return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
      }

      if (role.managed) {
        return interaction.reply({ content: 'I cannot remove managed roles.', ephemeral: true });
      }
      if (role.position >= guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'That role is higher than or equal to my highest role.', ephemeral: true });
      }
      if (!member.roles.cache.has(role.id)) {
        return interaction.reply({ content: `${user.tag} does not have **${role.name}**.`, ephemeral: true });
      }

      await interaction.deferReply();

      try {
        await member.roles.remove(role, `[Role remove by ${moderator.tag}]`);
      } catch (err) {
        return interaction.editReply({ content: `Failed to remove role: ${err.message}` });
      }

      // Deactivate any active temprole for this user+role
      const activeTemp = await storage.findActiveByUser(guild.id, user.id, 'temprole');
      if (activeTemp && activeTemp.extra?.roleId === role.id) {
        await storage.deactivateCase(guild.id, activeTemp.caseId);
      }

      const caseDoc = await storage.createCase({
        guildId: guild.id,
        userId: user.id,
        moderatorId: moderator.id,
        type: 'role',
        reason: `Removed role ${role.name}`,
        active: true,
        extra: { roleId: role.id, action: 'remove' },
      });

      const embed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle('Role Removed')
        .addFields(
          { name: 'User', value: `${user.tag}`, inline: true },
          { name: 'Role', value: `${role}`, inline: true },
          { name: 'Case ID', value: `#${caseDoc.caseId}`, inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    // ── role temp ─────────────────────────────────────────────
    if (sub === 'temp') {
      const user = interaction.options.getUser('user', true);
      const role = interaction.options.getRole('role', true);
      const durationStr = interaction.options.getString('duration', true);
      const durationMs = parseDuration(durationStr);

      if (!durationMs) {
        return interaction.reply({
          content: 'Invalid duration. Use formats like `30s`, `10m`, `2h`, `1d`.',
          ephemeral: true,
        });
      }

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (!member) {
        return interaction.reply({ content: 'That user is not in this server.', ephemeral: true });
      }

      if (role.managed) {
        return interaction.reply({ content: 'I cannot assign managed roles.', ephemeral: true });
      }
      if (role.position >= guild.members.me.roles.highest.position) {
        return interaction.reply({ content: 'That role is higher than or equal to my highest role.', ephemeral: true });
      }

      await interaction.deferReply();

      // Add role if they don't have it
      if (!member.roles.cache.has(role.id)) {
        try {
          await member.roles.add(role, `[Temp role by ${moderator.tag}] ${formatDuration(durationMs)}`);
        } catch (err) {
          return interaction.editReply({ content: `Failed to add role: ${err.message}` });
        }
      }

      // Deactivate previous active temprole for same user+role
      const existing = await storage.findActiveByUser(guild.id, user.id, 'temprole');
      if (existing && existing.extra?.roleId === role.id) {
        await storage.deactivateCase(guild.id, existing.caseId);
      }

      const expiresAt = new Date(Date.now() + durationMs);
      const caseDoc = await storage.createCase({
        guildId: guild.id,
        userId: user.id,
        moderatorId: moderator.id,
        type: 'temprole',
        reason: `Temporary role ${role.name}`,
        duration: durationMs,
        expiresAt,
        active: true,
        extra: { roleId: role.id },
      });

      const embed = new EmbedBuilder()
        .setColor(role.color || 0x3498db)
        .setTitle('Temporary Role Assigned')
        .addFields(
          { name: 'User', value: `${user.tag}`, inline: true },
          { name: 'Role', value: `${role}`, inline: true },
          { name: 'Duration', value: formatDuration(durationMs), inline: true },
          { name: 'Expires', value: `<t:${Math.floor(expiresAt.getTime() / 1000)}:R>`, inline: true },
          { name: 'Case ID', value: `#${caseDoc.caseId}`, inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    // ── role info ─────────────────────────────────────────────
    if (sub === 'info') {
      const role = interaction.options.getRole('role', true);

      const membersWithRole = role.members.size;
      const perms = role.permissions.toArray();
      const permList = perms.length
        ? perms.slice(0, 15).map(p => `\`${p}\``).join(', ') + (perms.length > 15 ? ` … +${perms.length - 15} more` : '')
        : 'None';

      const embed = new EmbedBuilder()
        .setColor(role.color || 0x95a5a6)
        .setTitle(`Role: ${role.name}`)
        .addFields(
          { name: 'ID', value: role.id, inline: true },
          { name: 'Color', value: role.hexColor, inline: true },
          { name: 'Position', value: String(role.position), inline: true },
          { name: 'Members', value: String(membersWithRole), inline: true },
          { name: 'Hoisted', value: role.hoist ? 'Yes' : 'No', inline: true },
          { name: 'Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
          { name: 'Managed', value: role.managed ? 'Yes (bot/integration)' : 'No', inline: true },
          { name: 'Created', value: `<t:${Math.floor(role.createdTimestamp / 1000)}:R>`, inline: true },
          { name: 'Permissions', value: permList },
        )
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
