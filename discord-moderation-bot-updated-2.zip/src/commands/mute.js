const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const { sendPunishmentDM } = require('../utils/dm');
const { parseDuration, formatDuration } = require('../utils/duration');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute / timeout management')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Mute (timeout) a user')
        .addUserOption(o => o.setName('user').setDescription('User to mute').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(true))
        .addStringOption(o => o.setName('duration').setDescription('Duration (e.g. 10m, 1h, 1d) — max 28 days').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('edit')
        .setDescription('Edit reason or duration of a mute')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('New reason').setRequired(true))
        .addStringOption(o => o.setName('duration').setDescription('New duration').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove a mute early')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List active mutes (50 per page)')
        .addIntegerOption(o =>
          o.setName('page').setDescription('Page number').setMinValue(1)
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const guild = interaction.guild;
    const moderator = interaction.user;

    const cmdKey = `mute.${sub}`;
    if (!(await canRunCommand(interaction.member, cmdKey))) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }

    if (sub === 'add') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);
      const durationStr = interaction.options.getString('duration', true);
      let durationMs = parseDuration(durationStr);

      if (!durationMs) {
        return interaction.reply({ content: 'Invalid duration. Examples: `10m`, `1h`, `1d`.', ephemeral: true });
      }

      // Discord timeout max is 28 days
      const maxMs = 28 * 24 * 60 * 60 * 1000;
      if (durationMs > maxMs) {
        durationMs = maxMs;
      }

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (!member) {
        return interaction.reply({ content: 'User is not in this server.', ephemeral: true });
      }
      if (!member.moderatable) {
        return interaction.reply({ content: 'I cannot timeout this user.', ephemeral: true });
      }

      const existing = await storage.findActiveByUser(guild.id, user.id, 'mute');
      if (existing) {
        return interaction.reply({
          content: `User already has an active mute (Case #${existing.caseId}).`,
          ephemeral: true,
        });
      }

      await interaction.deferReply();

      try {
        await member.timeout(durationMs, `[Mute by ${moderator.tag}] ${reason}`);
      } catch (err) {
        return interaction.editReply({ content: `Failed to mute: ${err.message}` });
      }

      const expiresAt = new Date(Date.now() + durationMs);
      const caseDoc = await storage.createCase({
        guildId: guild.id,
        userId: user.id,
        moderatorId: moderator.id,
        type: 'mute',
        reason,
        duration: durationMs,
        expiresAt,
        active: true,
      });

      const dmSent = await sendPunishmentDM(user, {
        type: 'mute',
        reason,
        caseId: caseDoc.caseId,
        guildName: guild.name,
        moderatorTag: moderator.tag,
        duration: durationMs,
        expiresAt,
      });

      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle('User Muted')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Case ID', value: `#${caseDoc.caseId}`, inline: true },
          { name: 'Duration', value: formatDuration(durationMs), inline: true },
          { name: 'Expires', value: `<t:${Math.floor(expiresAt.getTime() / 1000)}:R>`, inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
          { name: 'Reason', value: reason },
          { name: 'DM Sent', value: dmSent ? 'Yes' : 'No', inline: true },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'edit') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);
      const durationStr = interaction.options.getString('duration', true);
      let durationMs = parseDuration(durationStr);

      if (!durationMs) {
        return interaction.reply({ content: 'Invalid duration.', ephemeral: true });
      }
      const maxMs = 28 * 24 * 60 * 60 * 1000;
      if (durationMs > maxMs) durationMs = maxMs;

      const active = await storage.findActiveByUser(guild.id, user.id, 'mute');
      if (!active) {
        return interaction.reply({ content: 'No active mute for this user.', ephemeral: true });
      }

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (member && member.moderatable) {
        try {
          await member.timeout(durationMs, `[Mute edit by ${moderator.tag}] ${reason}`);
        } catch (_) {}
      }

      const expiresAt = new Date(Date.now() + durationMs);
      await storage.updateCase(guild.id, active.caseId, {
        reason,
        duration: durationMs,
        expiresAt,
      });

      return interaction.reply({
        content: `Updated mute Case #${active.caseId}: **${reason}**, ${formatDuration(durationMs)}`,
        ephemeral: true,
      });
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);

      const active = await storage.findActiveByUser(guild.id, user.id, 'mute');
      if (!active) {
        // Still try to clear Discord timeout
        const member = await guild.members.fetch(user.id).catch(() => null);
        if (member) await member.timeout(null, reason).catch(() => {});
        return interaction.reply({ content: 'No active mute found (cleared Discord timeout if possible).', ephemeral: true });
      }

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (member) {
        try {
          await member.timeout(null, `[Unmute by ${moderator.tag}] ${reason}`);
        } catch (_) {}
      }

      await storage.deactivateCase(guild.id, active.caseId);

      return interaction.reply({
        content: `Mute Case #${active.caseId} removed from ${user.tag}. Reason: ${reason}`,
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const page = interaction.options.getInteger('page') || 1;
      const result = await storage.getActiveCases(guild.id, 'mute', page, config.pageSize);

      if (result.total === 0) {
        return interaction.reply({ content: 'No active mutes.', ephemeral: true });
      }

      const lines = result.items.map(c => {
        const exp = c.expiresAt
          ? `<t:${Math.floor(new Date(c.expiresAt).getTime() / 1000)}:R>`
          : 'unknown';
        return `**#${c.caseId}** <@${c.userId}> — ${c.reason.slice(0, 40)}… (expires ${exp})`;
      });

      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle(`Active Mutes — Page ${result.page}/${result.totalPages}`)
        .setDescription(lines.join('\n'))
        .setFooter({ text: `Total: ${result.total}` });

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
