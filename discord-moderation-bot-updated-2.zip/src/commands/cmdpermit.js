const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const config = require('../config');

const VALID_COMMANDS = [
  'ban', 'ban.add', 'ban.remove', 'ban.edit', 'ban.list',
  'kick', 'kick.add', 'kick.edit', 'kick.list',
  'role', 'role.add', 'role.remove', 'role.temp', 'role.info',
  'warn', 'warn.add', 'warn.edit', 'warn.remove',
  'warns', 'warns.list', 'warns.user',
  'tempban', 'tempban.add', 'tempban.remove', 'tempban.edit', 'tempban.list',
  'softban', 'softban.add', 'softban.edit', 'softban.remove', 'softban.list',
  'mute', 'mute.add', 'mute.edit', 'mute.remove', 'mute.list',
  'cases',
  'appeal', 'appeal.submit', 'appeal.status', 'appeal.withdraw', 'appeal.list', 'appeal.decide', 'appeal.view', 'appeal.setchannel', 'appeal.mycases', 'appeal.toggle',
  'automod', 'setautomodlog', 'config', 'config.automod', 'automod.toggle', 'automod.setlog', 'automod.defaults', 'automod.bypass', 'automod.rule', 'automod.config', 'automod.words', 'automod.rulebypass', 'automod.status',
  'cmdpermit', 'cmdpermit.add', 'cmdpermit.remove', 'cmdpermit.list',
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cmdpermit')
    .setDescription('Manage command permissions for users and roles')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Allow a user or role to use a command (supports multiple commands)')
        .addStringOption(o =>
          o
            .setName('commands')
            .setDescription('Command(s) separated by space or comma (e.g. ban.add warn mute.list)')
            .setRequired(true)
        )
        .addUserOption(o => o.setName('user').setDescription('User to grant'))
        .addRoleOption(o => o.setName('role').setDescription('Role to grant'))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove permission for a user or role from command(s)')
        .addStringOption(o =>
          o
            .setName('commands')
            .setDescription('Command(s) separated by space or comma')
            .setRequired(true)
        )
        .addUserOption(o => o.setName('user').setDescription('User to remove'))
        .addRoleOption(o => o.setName('role').setDescription('Role to remove'))
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List all command permissions')
    ),

  async execute(interaction) {
    // Only owners or Administrators can manage permits by default
    const isOwner = config.ownerIds.includes(interaction.user.id);
    const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.Administrator);
    if (!isOwner && !isAdmin) {
      // Also allow if they have cmdpermit permission
      if (!(await canRunCommand(interaction.member, 'cmdpermit'))) {
        return interaction.reply({
          content: 'You do not have permission to manage command permits.',
          ephemeral: true,
        });
      }
    }

    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const guild = interaction.guild;

    if (sub === 'add' || sub === 'remove') {
      const commandsRaw = interaction.options.getString('commands', true);
      const user = interaction.options.getUser('user');
      const role = interaction.options.getRole('role');

      if (!user && !role) {
        return interaction.reply({
          content: 'You must provide either a `user` or a `role`.',
          ephemeral: true,
        });
      }
      if (user && role) {
        return interaction.reply({
          content: 'Provide only one of `user` or `role`.',
          ephemeral: true,
        });
      }

      const target = user
        ? { type: 'user', id: user.id, label: user.tag }
        : { type: 'role', id: role.id, label: role.name };

      // Parse multiple commands
      const commands = commandsRaw
        .split(/[\s,]+/)
        .map(c => c.trim().toLowerCase())
        .filter(Boolean);

      if (commands.length === 0) {
        return interaction.reply({ content: 'No valid commands provided.', ephemeral: true });
      }

      const invalid = commands.filter(c => !VALID_COMMANDS.includes(c));
      if (invalid.length) {
        return interaction.reply({
          content: `Invalid command(s): ${invalid.join(', ')}\nValid examples: ban, ban.add, warn.list, mute, cases, cmdpermit`,
          ephemeral: true,
        });
      }

      await interaction.deferReply({ ephemeral: true });

      const results = [];
      for (const cmd of commands) {
        if (sub === 'add') {
          await storage.addCmdPermitTarget(guild.id, cmd, { type: target.type, id: target.id });
          results.push(`✅ Added **${cmd}** for ${target.label}`);
        } else {
          await storage.removeCmdPermitTarget(guild.id, cmd, { type: target.type, id: target.id });
          results.push(`🗑️ Removed **${cmd}** for ${target.label}`);
        }
      }

      return interaction.editReply({ content: results.join('\n') });
    }

    if (sub === 'list') {
      const permits = await storage.getCmdPermits(guild.id);
      if (!permits.length) {
        return interaction.reply({
          content: 'No custom command permissions set. Administrators and bot owners always have access.',
          ephemeral: true,
        });
      }

      const lines = permits.map(p => {
        const targets = (p.targets || [])
          .map(t => (t.type === 'user' ? `<@${t.id}>` : `<@&${t.id}>`))
          .join(', ') || 'none';
        return `**${p.command}** → ${targets}`;
      });

      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle('Command Permissions')
        .setDescription(lines.join('\n'))
        .setFooter({ text: 'Owners & Administrators always have full access' });

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
