const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const { sendPunishmentDM } = require('../utils/dm');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('softban')
    .setDescription('Softban management (ban + immediate unban to delete messages)')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Softban a user')
        .addUserOption(o => o.setName('user').setDescription('User to softban').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(true))
        .addIntegerOption(o =>
          o
            .setName('delete_days')
            .setDescription('Days of messages to delete (0-7)')
            .setMinValue(0)
            .setMaxValue(7)
            .setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('edit')
        .setDescription('Edit the reason of a softban record')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('New reason').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Remove/mark inactive a softban record')
        .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List softban records (50 per page)')
        .addIntegerOption(o =>
          o.setName('page').setDescription('Page number').setMinValue(1)
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const guild = interaction.guild;
    const moderator = interaction.user;

    const cmdKey = `softban.${sub}`;
    if (!(await canRunCommand(interaction.member, cmdKey))) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }

    if (sub === 'add') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);
      const deleteDays = interaction.options.getInteger('delete_days', true);

      if (user.id === interaction.client.user.id || user.id === moderator.id) {
        return interaction.reply({ content: 'Cannot softban yourself or the bot.', ephemeral: true });
      }

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (member && !member.bannable) {
        return interaction.reply({ content: 'I cannot ban this user.', ephemeral: true });
      }

      await interaction.deferReply();

      try {
        // Softban = ban with message deletion then unban
        await guild.members.ban(user.id, {
          reason: `[Softban by ${moderator.tag}] ${reason}`,
          deleteMessageSeconds: deleteDays * 24 * 60 * 60,
        });
        await guild.members.unban(user.id, 'Softban complete');
      } catch (err) {
        return interaction.editReply({ content: `Softban failed: ${err.message}` });
      }

      const caseDoc = await storage.createCase({
        guildId: guild.id,
        userId: user.id,
        moderatorId: moderator.id,
        type: 'softban',
        reason,
        active: true,
        extra: { deleteDays },
      });

      const dmSent = await sendPunishmentDM(user, {
        type: 'softban',
        reason,
        caseId: caseDoc.caseId,
        guildName: guild.name,
        moderatorTag: moderator.tag,
      });

      const embed = new EmbedBuilder()
        .setColor(0x9b59b6)
        .setTitle('User Softbanned')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Case ID', value: `#${caseDoc.caseId}`, inline: true },
          { name: 'Messages deleted', value: `${deleteDays} day(s)`, inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
          { name: 'Reason', value: reason },
          { name: 'DM Sent', value: dmSent ? 'Yes' : 'No', inline: true },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'edit') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);

      const active = await storage.findActiveByUser(guild.id, user.id, 'softban');
      if (!active) {
        return interaction.reply({ content: 'No active softban record for this user.', ephemeral: true });
      }

      await storage.updateCase(guild.id, active.caseId, { reason });
      return interaction.reply({
        content: `Updated softban Case #${active.caseId} reason to: **${reason}**`,
        ephemeral: true,
      });
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);

      const active = await storage.findActiveByUser(guild.id, user.id, 'softban');
      if (!active) {
        return interaction.reply({ content: 'No active softban record for this user.', ephemeral: true });
      }

      await storage.deactivateCase(guild.id, active.caseId);
      return interaction.reply({
        content: `Softban Case #${active.caseId} marked inactive. Reason: ${reason}`,
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const page = interaction.options.getInteger('page') || 1;
      const result = await storage.getActiveCases(guild.id, 'softban', page, config.pageSize);

      if (result.total === 0) {
        return interaction.reply({ content: 'No softban records.', ephemeral: true });
      }

      const lines = result.items.map(c => {
        const days = c.extra?.deleteDays ?? '?';
        const date = new Date(c.createdAt).toLocaleDateString();
        return `**#${c.caseId}** <@${c.userId}> — ${c.reason.slice(0, 50)}… (${days}d msgs, ${date})`;
      });

      const embed = new EmbedBuilder()
        .setColor(0x9b59b6)
        .setTitle(`Softbans — Page ${result.page}/${result.totalPages}`)
        .setDescription(lines.join('\n'))
        .setFooter({ text: `Total: ${result.total}` });

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
