const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const { formatDuration } = require('../utils/duration');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cases')
    .setDescription('View a specific moderation case')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o =>
      o.setName('user').setDescription('User the case belongs to').setRequired(true)
    )
    .addIntegerOption(o =>
      o.setName('case_id').setDescription('Case ID number').setRequired(true).setMinValue(1)
    ),

  async execute(interaction) {
    if (!(await canRunCommand(interaction.member, 'cases'))) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }

    const user = interaction.options.getUser('user', true);
    const caseId = interaction.options.getInteger('case_id', true);
    const storage = getStorage();
    const guild = interaction.guild;

    const caseDoc = await storage.getCase(guild.id, caseId);
    if (!caseDoc) {
      return interaction.reply({ content: `Case #${caseId} not found.`, ephemeral: true });
    }
    if (caseDoc.userId !== user.id) {
      return interaction.reply({
        content: `Case #${caseId} does not belong to ${user.tag}.`,
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor(caseDoc.active ? 0xe74c3c : 0x95a5a6)
      .setTitle(`Case #${caseDoc.caseId} — ${caseDoc.type.toUpperCase()}`)
      .addFields(
        { name: 'User', value: `<@${caseDoc.userId}> (${caseDoc.userId})`, inline: true },
        { name: 'Moderator', value: `<@${caseDoc.moderatorId}>`, inline: true },
        { name: 'Status', value: caseDoc.active ? '🟢 Active' : '🔴 Inactive', inline: true },
        { name: 'Reason', value: caseDoc.reason || 'No reason' },
        {
          name: 'Created',
          value: `<t:${Math.floor(new Date(caseDoc.createdAt).getTime() / 1000)}:F>`,
          inline: true,
        },
      )
      .setTimestamp(new Date(caseDoc.createdAt));

    if (caseDoc.duration) {
      embed.addFields({
        name: 'Duration',
        value: formatDuration(caseDoc.duration),
        inline: true,
      });
    }
    if (caseDoc.expiresAt) {
      embed.addFields({
        name: 'Expires / Expired',
        value: `<t:${Math.floor(new Date(caseDoc.expiresAt).getTime() / 1000)}:R>`,
        inline: true,
      });
    }
    if (caseDoc.extra && Object.keys(caseDoc.extra).length) {
      embed.addFields({
        name: 'Extra',
        value: '```json\n' + JSON.stringify(caseDoc.extra, null, 2) + '\n```',
      });
    }

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
