const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const { sendPunishmentDM } = require('../utils/dm');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban management commands')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addSubcommand(sub =>
      sub
        .setName('add')
        .setDescription('Ban a user')
        .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason for the ban').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('remove')
        .setDescription('Unban a user')
        .addUserOption(o => o.setName('user').setDescription('User to unban').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('Reason for the unban').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('edit')
        .setDescription('Edit the reason of an active ban case')
        .addUserOption(o => o.setName('user').setDescription('Banned user').setRequired(true))
        .addStringOption(o => o.setName('reason').setDescription('New reason').setRequired(true))
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List all banned users (50 per page)')
        .addIntegerOption(o =>
          o.setName('page').setDescription('Page number').setMinValue(1)
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const guild = interaction.guild;
    const moderator = interaction.user;

    // Permission check
    const cmdKey = `ban.${sub}`;
    if (!(await canRunCommand(interaction.member, cmdKey))) {
      return interaction.reply({
        content: 'You do not have permission to use this command.',
        ephemeral: true,
      });
    }

    if (sub === 'add') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);

      if (user.id === interaction.client.user.id) {
        return interaction.reply({ content: 'I cannot ban myself.', ephemeral: true });
      }
      if (user.id === moderator.id) {
        return interaction.reply({ content: 'You cannot ban yourself.', ephemeral: true });
      }

      const member = await guild.members.fetch(user.id).catch(() => null);
      if (member) {
        if (!member.bannable) {
          return interaction.reply({
            content: 'I cannot ban this user (higher role or missing permissions).',
            ephemeral: true,
          });
        }
      }

      // Check if already banned (active ban case)
      const existing = await storage.findActiveByUser(guild.id, user.id, 'ban');
      if (existing) {
        return interaction.reply({
          content: `This user already has an active ban (Case #${existing.caseId}). Use \`/ban edit\` or \`/ban remove\` first.`,
          ephemeral: true,
        });
      }

      await interaction.deferReply();

      try {
        await guild.members.ban(user.id, { reason: `[${moderator.tag}] ${reason}`, deleteMessageSeconds: 0 });
      } catch (err) {
        return interaction.editReply({ content: `Failed to ban: ${err.message}` });
      }

      const caseDoc = await storage.createCase({
        guildId: guild.id,
        userId: user.id,
        moderatorId: moderator.id,
        type: 'ban',
        reason,
        active: true,
      });

      const dmSent = await sendPunishmentDM(user, {
        type: 'ban',
        reason,
        caseId: caseDoc.caseId,
        guildName: guild.name,
        moderatorTag: moderator.tag,
      });

      const embed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle('User Banned')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Case ID', value: `#${caseDoc.caseId}`, inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
          { name: 'Reason', value: reason },
          { name: 'DM Sent', value: dmSent ? 'Yes' : 'No (DMs closed)', inline: true },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);

      await interaction.deferReply();

      const active = await storage.findActiveByUser(guild.id, user.id, 'ban');
      if (!active) {
        // Still try Discord unban in case data is out of sync
        try {
          await guild.members.unban(user.id, `[${moderator.tag}] ${reason}`);
        } catch (_) {}
        return interaction.editReply({ content: 'No active ban case found for this user (attempted Discord unban anyway).' });
      }

      try {
        await guild.members.unban(user.id, `[${moderator.tag}] ${reason}`);
      } catch (err) {
        // User might already be unbanned
      }

      await storage.deactivateCase(guild.id, active.caseId);

      const embed = new EmbedBuilder()
        .setColor(0x2ecc71)
        .setTitle('User Unbanned')
        .addFields(
          { name: 'User', value: `${user.tag} (${user.id})`, inline: true },
          { name: 'Case ID', value: `#${active.caseId}`, inline: true },
          { name: 'Moderator', value: moderator.tag, inline: true },
          { name: 'Reason', value: reason },
        )
        .setTimestamp();

      return interaction.editReply({ embeds: [embed] });
    }

    if (sub === 'edit') {
      const user = interaction.options.getUser('user', true);
      const reason = interaction.options.getString('reason', true);

      const active = await storage.findActiveByUser(guild.id, user.id, 'ban');
      if (!active) {
        return interaction.reply({ content: 'No active ban found for this user.', ephemeral: true });
      }

      await storage.updateCase(guild.id, active.caseId, { reason });

      return interaction.reply({
        content: `Updated ban Case #${active.caseId} reason to: **${reason}**`,
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const page = interaction.options.getInteger('page') || 1;
      const result = await storage.getActiveCases(guild.id, 'ban', page, config.pageSize);

      if (result.total === 0) {
        return interaction.reply({ content: 'No active bans.', ephemeral: true });
      }

      const lines = result.items.map(c => {
        const date = new Date(c.createdAt).toLocaleDateString();
        return `**#${c.caseId}** <@${c.userId}> — ${c.reason.slice(0, 60)}${c.reason.length > 60 ? '…' : ''} (${date})`;
      });

      const embed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle(`Active Bans — Page ${result.page}/${result.totalPages}`)
        .setDescription(lines.join('\n') || 'None')
        .setFooter({ text: `Total: ${result.total}` });

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
