/**
 * /help — lists bot commands by category.
 * Place at: src/commands/help.js
 */
const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} = require('discord.js');

const CATEGORIES = [
  {
    name: '🔨 Moderation',
    commands: [
      '`/ban` — add · remove · edit · list',
      '`/kick` — add · edit · list',
      '`/tempban` — add · remove · edit · list',
      '`/softban` — add · edit · remove · list',
      '`/mute` — add · edit · remove · list',
      '`/warn` — add · edit · remove',
      '`/warns` — list · user',
      '`/cases` — view a case by ID',
    ],
  },
  {
    name: '🛡️ AutoMod',
    commands: [
      '`/automod` — **open the AutoMod control panel**',
      'Panel: enable/disable, log channel, rules, actions, thresholds,',
      'bypasses, bad words, **allowed link domains** (everything else blocked).',
    ],
  },
  {
    name: '📜 Appeals',
    commands: [
      '`/appeal submit` — appeal a case (works in **DMs** if banned)',
      '`/appeal status` · `withdraw` · `list` · `view` · `decide`',
      '`/appeal setchannel` · `toggle` · `mycases`',
    ],
  },
  {
    name: '👤 Roles',
    commands: [
      '`/role add` · `remove` · `temp` · `info`',
    ],
  },
  {
    name: '⚙️ Admin',
    commands: [
      '`/cmdpermit` — allow users/roles to use specific commands',
      '`/help` — this menu',
      '`/help command:<name>` — details for one area',
    ],
  },
];

const DETAILS = {
  automod: {
    title: 'AutoMod',
    body:
      '**`/automod`** opens an interactive panel (buttons & menus).\n\n' +
      '**Anti-Link:** blocks **all** links by default (`youtube.com`, `https://...`, markdown links, `youtube[.]com`, etc.).\n' +
      'Only domains you add under **Allowed Links** are permitted.\n\n' +
      '**Rules:** spam, channel spam, caps, invites, mass mention, emoji spam, bad words, zalgo, duplicates, newlines, @everyone, attachments, stickers.\n\n' +
      '**Actions:** delete, warn, mute, kick, ban, softban, tempban (uses your built-in case system).\n' +
      'Duration is only for mute & tempban.',
  },
  ban: {
    title: 'Ban',
    body: '`/ban add|remove|edit|list` — permanent bans with cases & DMs.',
  },
  mute: {
    title: 'Mute',
    body: '`/mute add|edit|remove|list` — Discord timeouts + cases. Duration required on add.',
  },
  appeal: {
    title: 'Appeals',
    body:
      'Users can `/appeal submit` with a case ID.\n' +
      'If banned, **DM the bot** and pass `server_id`.\n' +
      'Staff review in the appeal channel (buttons) or `/appeal decide`.',
  },
  warn: {
    title: 'Warns',
    body: '`/warn add|edit|remove` and `/warns list|user` — warning cases.',
  },
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show bot commands and how to use them')
    .addStringOption(o =>
      o
        .setName('command')
        .setDescription('Get details about a specific feature')
        .addChoices(
          { name: 'AutoMod', value: 'automod' },
          { name: 'Ban', value: 'ban' },
          { name: 'Mute', value: 'mute' },
          { name: 'Warn', value: 'warn' },
          { name: 'Appeals', value: 'appeal' },
        )
    ),

  async execute(interaction) {
    const topic = interaction.options.getString('command');

    if (topic && DETAILS[topic]) {
      const d = DETAILS[topic];
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x5865f2)
            .setTitle(`Help — ${d.title}`)
            .setDescription(d.body)
            .setTimestamp(),
        ],
        ephemeral: true,
      });
    }

    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle('Bot Help')
      .setDescription('Slash commands grouped by category.\nUse `/help command:` for more detail on a feature.')
      .setTimestamp();

    for (const cat of CATEGORIES) {
      embed.addFields({
        name: cat.name,
        value: cat.commands.join('\n'),
      });
    }

    embed.setFooter({ text: 'AutoMod panel: /automod  ·  Appeals work in DMs if you are banned' });

    return interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
