const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  InteractionContextType,
} = require('discord.js');
const { getStorage } = require('../storage');
const { canRunCommand } = require('../utils/permissions');
const config = require('../config');

const APPEALABLE_TYPES = ['ban', 'tempban', 'softban', 'mute', 'warn', 'kick'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('appeal')
    .setDescription('Appeal system — submit and review punishment appeals')
    // Available in servers AND in DMs (so banned users can still appeal)
    .setContexts(InteractionContextType.Guild, InteractionContextType.BotDM, InteractionContextType.PrivateChannel)
    .addSubcommand(sub =>
      sub
        .setName('submit')
        .setDescription('Submit an appeal (works in DMs if you are banned)')
        .addIntegerOption(o =>
          o.setName('case_id').setDescription('Case ID to appeal').setRequired(true).setMinValue(1)
        )
        .addStringOption(o =>
          o.setName('reason').setDescription('Why should this be overturned?').setRequired(true)
        )
        .addStringOption(o =>
          o.setName('server_id').setDescription('Server ID (required in DMs — right-click server icon → Copy Server ID)')
        )
        .addStringOption(o =>
          o.setName('evidence').setDescription('Optional evidence (links, details)')
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('status')
        .setDescription('Check your appeal status (works in DMs)')
        .addIntegerOption(o =>
          o.setName('appeal_id').setDescription('Specific appeal ID')
        )
        .addStringOption(o =>
          o.setName('server_id').setDescription('Server ID (needed in DMs)')
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('withdraw')
        .setDescription('Withdraw a pending appeal (works in DMs)')
        .addIntegerOption(o =>
          o.setName('appeal_id').setDescription('Appeal ID').setRequired(true).setMinValue(1)
        )
        .addStringOption(o =>
          o.setName('server_id').setDescription('Server ID (needed in DMs)')
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('list')
        .setDescription('List appeals')
        .addStringOption(o =>
          o
            .setName('filter')
            .setDescription('Filter by status')
            .addChoices(
              { name: 'Pending', value: 'pending' },
              { name: 'Accepted', value: 'accepted' },
              { name: 'Denied', value: 'denied' },
              { name: 'Withdrawn', value: 'withdrawn' },
              { name: 'All', value: 'all' },
            )
        )
        .addIntegerOption(o =>
          o.setName('page').setDescription('Page number').setMinValue(1)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('decide')
        .setDescription('Accept or deny an appeal (staff only)')
        .addIntegerOption(o =>
          o.setName('appeal_id').setDescription('Appeal ID').setRequired(true).setMinValue(1)
        )
        .addStringOption(o =>
          o
            .setName('decision')
            .setDescription('Decision')
            .setRequired(true)
            .addChoices(
              { name: 'Accept', value: 'accepted' },
              { name: 'Deny', value: 'denied' },
            )
        )
        .addStringOption(o =>
          o.setName('reason').setDescription('Staff reason shown to the user')
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('view')
        .setDescription('View full details of an appeal')
        .addIntegerOption(o =>
          o.setName('appeal_id').setDescription('Appeal ID').setRequired(true).setMinValue(1)
        )
        .addStringOption(o =>
          o.setName('server_id').setDescription('Server ID (needed in DMs)')
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('setchannel')
        .setDescription('Set the staff channel for new appeals')
        .addChannelOption(o =>
          o.setName('channel').setDescription('Text channel for appeal reviews').setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('toggle')
        .setDescription('Enable or disable the appeal system for this server')
        .addBooleanOption(o =>
          o.setName('enabled').setDescription('Turn appeals on (true) or off (false)').setRequired(true)
        )
    )
    .addSubcommand(sub =>
      sub
        .setName('mycases')
        .setDescription('List your punishment cases so you know what to appeal (works in DMs)')
        .addStringOption(o =>
          o.setName('server_id').setDescription('Server ID (needed in DMs)')
        )
    ),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const storage = getStorage();
    const user = interaction.user;
    const inDm = !interaction.guild;

    // Staff-only subs must be used in a server
    const staffSubs = ['decide', 'setchannel', 'toggle'];
    if (staffSubs.includes(sub) && inDm) {
      return interaction.reply({
        content: 'This command must be used **inside the server**, not in DMs.',
        ephemeral: true,
      });
    }

    if (staffSubs.includes(sub)) {
      const allowed =
        (await canRunCommand(interaction.member, `appeal.${sub}`)) ||
        interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
        interaction.member.permissions.has(PermissionFlagsBits.Administrator) ||
        config.ownerIds.includes(user.id);
      if (!allowed) {
        return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
      }
    }

    // Resolve guild id (from interaction or server_id option)
    const guildId = await resolveGuildId(interaction, storage);
    if (!guildId && ['submit', 'status', 'withdraw', 'view', 'mycases'].includes(sub)) {
      return interaction.reply({
        content:
          'Could not determine the server.\n' +
          '• In a server: just run the command normally.\n' +
          '• In DMs: pass `server_id` (Developer Mode → right-click the server → Copy Server ID).',
        ephemeral: true,
      });
    }

    // ── toggle ────────────────────────────────────────────────
    if (sub === 'toggle') {
      const enabled = interaction.options.getBoolean('enabled', true);
      await storage.setGuildSettings(interaction.guild.id, { appealsEnabled: enabled });
      return interaction.reply({
        content: enabled
          ? '🟢 Appeal system is now **enabled**. Users can submit appeals (including via DM if banned).'
          : '🔴 Appeal system is now **disabled**. New appeals will be rejected.',
        ephemeral: true,
      });
    }

    // ── setchannel ────────────────────────────────────────────
    if (sub === 'setchannel') {
      const channel = interaction.options.getChannel('channel', true);
      if (!channel.isTextBased()) {
        return interaction.reply({ content: 'Please choose a text channel.', ephemeral: true });
      }
      await storage.setGuildSettings(interaction.guild.id, { appealChannelId: channel.id });
      return interaction.reply({
        content: `Appeal review channel set to ${channel}. New appeals will be posted there with Accept/Deny buttons.`,
        ephemeral: true,
      });
    }

    // Check if appeals are enabled (for user-facing actions)
    if (['submit'].includes(sub)) {
      const settings = await storage.getGuildSettings(guildId);
      if (settings.appealsEnabled === false) {
        return interaction.reply({
          content: 'The appeal system is currently **disabled** on this server.',
          ephemeral: true,
        });
      }
    }

    // ── mycases (help banned users find case IDs) ─────────────
    if (sub === 'mycases') {
      await interaction.deferReply({ ephemeral: true });
      const cases = await storage.getCasesByUser(guildId, user.id);
      if (!cases.length) {
        return interaction.editReply({ content: 'No cases found for you in that server.' });
      }
      const lines = cases.slice(0, 20).map(c => {
        const status = c.active ? '🟢' : '🔴';
        const date = new Date(c.createdAt).toLocaleDateString();
        return `${status} **#${c.caseId}** \`${c.type}\` — ${(c.reason || '').slice(0, 50)} (${date})`;
      });
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x3498db)
            .setTitle('Your Cases')
            .setDescription(lines.join('\n'))
            .setFooter({ text: 'Use /appeal submit case_id:<id> reason:... to appeal' }),
        ],
      });
    }

    // ── submit ────────────────────────────────────────────────
    if (sub === 'submit') {
      const caseId = interaction.options.getInteger('case_id', true);
      const reason = interaction.options.getString('reason', true);
      const evidence = interaction.options.getString('evidence') || null;

      if (reason.length < 10) {
        return interaction.reply({
          content: 'Appeal reason must be at least 10 characters.',
          ephemeral: true,
        });
      }

      const caseDoc = await storage.getCase(guildId, caseId);
      if (!caseDoc) {
        return interaction.reply({ content: `Case #${caseId} not found in that server.`, ephemeral: true });
      }
      if (caseDoc.userId !== user.id) {
        return interaction.reply({ content: 'You can only appeal your own cases.', ephemeral: true });
      }
      if (!APPEALABLE_TYPES.includes(caseDoc.type)) {
        return interaction.reply({
          content: `Cases of type \`${caseDoc.type}\` cannot be appealed.`,
          ephemeral: true,
        });
      }

      const existing = await storage.getAppealsByCase(guildId, caseId);
      if (existing.find(a => a.status === 'pending')) {
        return interaction.reply({
          content: `You already have a **pending** appeal for Case #${caseId}.`,
          ephemeral: true,
        });
      }

      const userAppeals = await storage.getAppealsByUser(guildId, user.id);
      const recentDenied = userAppeals.find(a => {
        if (a.status !== 'denied') return false;
        const age = Date.now() - new Date(a.updatedAt || a.createdAt).getTime();
        return age < 24 * 60 * 60 * 1000;
      });
      if (recentDenied) {
        return interaction.reply({
          content: 'You had an appeal denied in the last 24 hours. Please wait before submitting another.',
          ephemeral: true,
        });
      }

      await interaction.deferReply({ ephemeral: true });

      const appeal = await storage.createAppeal({
        guildId,
        caseId,
        userId: user.id,
        reason,
        evidence,
        status: 'pending',
      });

      // Post to staff channel
      const settings = await storage.getGuildSettings(guildId);
      const channelId = settings?.appealChannelId;
      let posted = false;

      if (channelId) {
        try {
          const guild = await interaction.client.guilds.fetch(guildId).catch(() => null);
          const channel = guild && (await guild.channels.fetch(channelId).catch(() => null));
          if (channel && channel.isTextBased()) {
            const embed = buildAppealEmbed(appeal, caseDoc, user);
            embed.setFooter({ text: inDm ? 'Submitted via DM (user may be banned)' : 'Submitted in server' });
            const row = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId(`appeal:accept:${appeal.appealId}`)
                .setLabel('Accept')
                .setStyle(ButtonStyle.Success),
              new ButtonBuilder()
                .setCustomId(`appeal:deny:${appeal.appealId}`)
                .setLabel('Deny')
                .setStyle(ButtonStyle.Danger),
              new ButtonBuilder()
                .setCustomId(`appeal:info:${appeal.appealId}`)
                .setLabel('View Case')
                .setStyle(ButtonStyle.Secondary),
            );
            const msg = await channel.send({
              content: `New appeal from <@${user.id}>${inDm ? ' (via DM)' : ''}`,
              embeds: [embed],
              components: [row],
            });
            await storage.updateAppeal(guildId, appeal.appealId, {
              messageId: msg.id,
              channelId: channel.id,
            });
            posted = true;
          }
        } catch (err) {
          console.error('[Appeal] Failed to post to review channel:', err.message);
        }
      }

      return interaction.editReply({
        content:
          `✅ Appeal **#${appeal.appealId}** submitted for Case #${caseId}.\n` +
          `Status: **Pending**\n` +
          (posted
            ? 'Staff have been notified in the review channel.'
            : '⚠️ No review channel set — staff should use `/appeal list` / `/appeal decide`.\n' +
              'Admins: `/appeal setchannel`'),
      });
    }

    // ── status ────────────────────────────────────────────────
    if (sub === 'status') {
      const appealId = interaction.options.getInteger('appeal_id');
      if (appealId) {
        const appeal = await storage.getAppeal(guildId, appealId);
        if (!appeal) {
          return interaction.reply({ content: `Appeal #${appealId} not found.`, ephemeral: true });
        }
        if (appeal.userId !== user.id && !(interaction.guild && (await isStaff(interaction)))) {
          return interaction.reply({ content: 'You can only view your own appeals.', ephemeral: true });
        }
        const caseDoc = await storage.getCase(guildId, appeal.caseId);
        return interaction.reply({
          embeds: [buildAppealEmbed(appeal, caseDoc, null)],
          ephemeral: true,
        });
      }

      const appeals = await storage.getAppealsByUser(guildId, user.id);
      if (!appeals.length) {
        return interaction.reply({ content: 'You have no appeals in that server.', ephemeral: true });
      }
      const lines = appeals.slice(0, 15).map(a => {
        const icon = statusIcon(a.status);
        return `${icon} **#${a.appealId}** Case #${a.caseId} — \`${a.status}\` — ${new Date(a.createdAt).toLocaleDateString()}`;
      });
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x3498db)
            .setTitle('Your Appeals')
            .setDescription(lines.join('\n'))
            .setFooter({ text: `Total: ${appeals.length}` }),
        ],
        ephemeral: true,
      });
    }

    // ── withdraw ──────────────────────────────────────────────
    if (sub === 'withdraw') {
      const appealId = interaction.options.getInteger('appeal_id', true);
      const appeal = await storage.getAppeal(guildId, appealId);
      if (!appeal) {
        return interaction.reply({ content: `Appeal #${appealId} not found.`, ephemeral: true });
      }
      if (appeal.userId !== user.id) {
        return interaction.reply({ content: 'You can only withdraw your own appeals.', ephemeral: true });
      }
      if (appeal.status !== 'pending') {
        return interaction.reply({
          content: `Appeal #${appealId} is already **${appeal.status}**.`,
          ephemeral: true,
        });
      }

      await storage.updateAppeal(guildId, appealId, {
        status: 'withdrawn',
        updatedAt: new Date().toISOString(),
      });
      await disableAppealButtons(interaction.client, appeal);

      return interaction.reply({
        content: `Appeal **#${appealId}** has been withdrawn.`,
        ephemeral: true,
      });
    }

    // ── list (guild only for staff view) ──────────────────────
    if (sub === 'list') {
      if (inDm) {
        return interaction.reply({
          content: 'Use `/appeal status` in DMs to see your own appeals. Staff list must be used in the server.',
          ephemeral: true,
        });
      }
      const filter = interaction.options.getString('filter') || 'pending';
      const page = interaction.options.getInteger('page') || 1;
      const staff = await isStaff(interaction);

      let result;
      if (staff) {
        result = await storage.getAppeals(guildId, filter === 'all' ? null : filter, page, config.pageSize);
      } else {
        const all = await storage.getAppealsByUser(guildId, user.id);
        const filtered = filter === 'all' ? all : all.filter(a => a.status === filter);
        const total = filtered.length;
        const totalPages = Math.ceil(total / config.pageSize) || 1;
        const skip = (page - 1) * config.pageSize;
        result = {
          items: filtered.slice(skip, skip + config.pageSize),
          total,
          page,
          pageSize: config.pageSize,
          totalPages,
        };
      }

      if (!result.items.length) {
        return interaction.reply({ content: 'No appeals found.', ephemeral: true });
      }

      const lines = result.items.map(a => {
        const icon = statusIcon(a.status);
        return `${icon} **#${a.appealId}** <@${a.userId}> Case #${a.caseId} — \`${a.status}\``;
      });

      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x9b59b6)
            .setTitle(`Appeals (${filter}) — Page ${result.page}/${result.totalPages}`)
            .setDescription(lines.join('\n'))
            .setFooter({ text: `Total: ${result.total}` }),
        ],
        ephemeral: true,
      });
    }

    // ── decide ────────────────────────────────────────────────
    if (sub === 'decide') {
      const appealId = interaction.options.getInteger('appeal_id', true);
      const decision = interaction.options.getString('decision', true);
      const staffReason = interaction.options.getString('reason') || 'No reason provided';

      await interaction.deferReply({ ephemeral: true });
      const result = await processDecision(
        interaction.client, storage, interaction.guild, appealId, decision, user, staffReason
      );
      return interaction.editReply({ content: result.message });
    }

    // ── view ──────────────────────────────────────────────────
    if (sub === 'view') {
      const appealId = interaction.options.getInteger('appeal_id', true);
      const appeal = await storage.getAppeal(guildId, appealId);
      if (!appeal) {
        return interaction.reply({ content: `Appeal #${appealId} not found.`, ephemeral: true });
      }
      if (appeal.userId !== user.id && !(interaction.guild && (await isStaff(interaction)))) {
        return interaction.reply({ content: 'You can only view your own appeals.', ephemeral: true });
      }
      const caseDoc = await storage.getCase(guildId, appeal.caseId);
      return interaction.reply({
        embeds: [buildAppealEmbed(appeal, caseDoc, null)],
        ephemeral: true,
      });
    }
  },
};

// ─── Helpers ──────────────────────────────────────────────────

async function resolveGuildId(interaction, storage) {
  if (interaction.guild) return interaction.guild.id;

  const raw = interaction.options.getString('server_id');
  if (raw) {
    const id = raw.replace(/['"]/g, '').trim();
    if (/^\d{17,20}$/.test(id)) return id;
  }

  // Try to find a single guild where this user has cases
  try {
    const guilds = interaction.client.guilds.cache;
    const hits = [];
    for (const [gid] of guilds) {
      const cases = await storage.getCasesByUser(gid, interaction.user.id);
      if (cases.length) hits.push(gid);
    }
    if (hits.length === 1) return hits[0];
  } catch (_) {}

  return null;
}

async function isStaff(interaction) {
  if (!interaction.guild) return false;
  if (config.ownerIds.includes(interaction.user.id)) return true;
  if (interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) return true;
  if (interaction.member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  return canRunCommand(interaction.member, 'appeal.decide');
}

function statusIcon(status) {
  return { pending: '🟡', accepted: '🟢', denied: '🔴', withdrawn: '⚪' }[status] || '•';
}

function buildAppealEmbed(appeal, caseDoc, appellantUser) {
  const embed = new EmbedBuilder()
    .setColor(
      appeal.status === 'pending' ? 0xf1c40f :
      appeal.status === 'accepted' ? 0x2ecc71 :
      appeal.status === 'denied' ? 0xe74c3c : 0x95a5a6
    )
    .setTitle(`Appeal #${appeal.appealId} — ${appeal.status.toUpperCase()}`)
    .addFields(
      { name: 'User', value: `<@${appeal.userId}>`, inline: true },
      { name: 'Case ID', value: `#${appeal.caseId}`, inline: true },
      { name: 'Punishment', value: caseDoc ? `\`${caseDoc.type}\`` : 'unknown', inline: true },
      { name: 'Appeal Reason', value: appeal.reason || '—' },
    )
    .setTimestamp(new Date(appeal.createdAt));

  if (appeal.evidence) {
    embed.addFields({ name: 'Evidence', value: appeal.evidence.slice(0, 1024) });
  }
  if (caseDoc) {
    embed.addFields({
      name: 'Original Case Reason',
      value: (caseDoc.reason || '—').slice(0, 1024),
    });
    embed.addFields({
      name: 'Case Status',
      value: caseDoc.active ? '🟢 Active' : '🔴 Inactive',
      inline: true,
    });
  }
  if (appeal.staffId) {
    embed.addFields(
      { name: 'Reviewed by', value: `<@${appeal.staffId}>`, inline: true },
      { name: 'Staff Note', value: appeal.staffReason || '—', inline: false },
    );
  }
  if (appellantUser) {
    embed.setAuthor({ name: appellantUser.tag, iconURL: appellantUser.displayAvatarURL() });
  }
  return embed;
}

async function disableAppealButtons(client, appeal) {
  if (!appeal.messageId || !appeal.channelId) return;
  try {
    const channel = await client.channels.fetch(appeal.channelId).catch(() => null);
    if (!channel) return;
    const msg = await channel.messages.fetch(appeal.messageId).catch(() => null);
    if (!msg) return;
    const disabled = msg.components.map(row => {
      const newRow = ActionRowBuilder.from(row);
      newRow.components.forEach(c => c.setDisabled(true));
      return newRow;
    });
    await msg.edit({ components: disabled }).catch(() => {});
  } catch (_) {}
}

async function processDecision(client, storage, guild, appealId, decision, staffUser, staffReason) {
  const appeal = await storage.getAppeal(guild.id, appealId);
  if (!appeal) {
    return { ok: false, message: `Appeal #${appealId} not found.` };
  }
  if (appeal.status !== 'pending') {
    return { ok: false, message: `Appeal #${appealId} is already **${appeal.status}**.` };
  }

  await storage.updateAppeal(guild.id, appealId, {
    status: decision,
    staffId: staffUser.id,
    staffReason: staffReason || 'No reason provided',
    updatedAt: new Date().toISOString(),
  });

  const caseDoc = await storage.getCase(guild.id, appeal.caseId);
  let actionNote = '';

  if (decision === 'accepted' && caseDoc && caseDoc.active) {
    try {
      actionNote = await reversePunishment(client, guild, caseDoc, storage, staffUser);
    } catch (err) {
      actionNote = ` (reversal warning: ${err.message})`;
    }
  }

  const updated = await storage.getAppeal(guild.id, appealId);
  await disableAppealButtons(client, updated);
  if (updated.channelId && updated.messageId) {
    try {
      const channel = await client.channels.fetch(updated.channelId).catch(() => null);
      const msg = channel && (await channel.messages.fetch(updated.messageId).catch(() => null));
      if (msg) {
        await msg.edit({
          embeds: [buildAppealEmbed(updated, caseDoc, null)],
          components: msg.components.map(row => {
            const newRow = ActionRowBuilder.from(row);
            newRow.components.forEach(c => c.setDisabled(true));
            return newRow;
          }),
        }).catch(() => {});
      }
    } catch (_) {}
  }

  try {
    const appellant = await client.users.fetch(appeal.userId);
    const dmEmbed = new EmbedBuilder()
      .setColor(decision === 'accepted' ? 0x2ecc71 : 0xe74c3c)
      .setTitle(`Appeal #${appealId} ${decision === 'accepted' ? 'Accepted' : 'Denied'}`)
      .setDescription(
        decision === 'accepted'
          ? `Your appeal for Case #${appeal.caseId} was **accepted**.${actionNote}`
          : `Your appeal for Case #${appeal.caseId} was **denied**.`
      )
      .addFields(
        { name: 'Staff Note', value: staffReason || 'No reason provided' },
        { name: 'Reviewed by', value: staffUser.tag },
      )
      .setTimestamp();
    await appellant.send({ embeds: [dmEmbed] });
  } catch (_) {}

  return {
    ok: true,
    message:
      `Appeal **#${appealId}** marked as **${decision}**.${actionNote}\n` +
      `User has been notified (if DMs are open).`,
  };
}

async function reversePunishment(client, guild, caseDoc, storage, staffUser) {
  const type = caseDoc.type;
  const userId = caseDoc.userId;
  let note = '';

  if (type === 'ban' || type === 'tempban') {
    try {
      await guild.members.unban(userId, `[Appeal accepted by ${staffUser.tag}]`);
      note = ' User has been unbanned.';
    } catch (err) {
      note = ` Could not unban: ${err.message}`;
    }
  } else if (type === 'mute') {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (member) {
      try {
        await member.timeout(null, `[Appeal accepted by ${staffUser.tag}]`);
        note = ' Mute/timeout removed.';
      } catch (err) {
        note = ` Could not remove timeout: ${err.message}`;
      }
    }
  }

  await storage.deactivateCase(guild.id, caseDoc.caseId);
  note += ` Case #${caseDoc.caseId} marked inactive.`;
  return note;
}

module.exports.processDecision = processDecision;
module.exports.buildAppealEmbed = buildAppealEmbed;
module.exports.isStaff = isStaff;
