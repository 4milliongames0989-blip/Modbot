require('dotenv').config();

function clean(val) {
  if (val == null) return null;
  return String(val).replace(/['"]/g, '').trim() || null;
}

module.exports = {
  token: clean(process.env.DISCORD_TOKEN),
  clientId: clean(process.env.CLIENT_ID),
  guildId: clean(process.env.GUILD_ID) || null,
  storageType: (clean(process.env.STORAGE_TYPE) || 'mongodb').toLowerCase(),
  mongoUri: clean(process.env.MONGODB_URI) || 'mongodb://localhost:27017/modbot',
  dataChannelId: clean(process.env.DATA_CHANNEL_ID) || null,
  ownerIds: (process.env.OWNER_IDS || '')
    .split(',')
    .map(id => clean(id))
    .filter(Boolean),
  // Default page size for lists
  pageSize: 50,
};
