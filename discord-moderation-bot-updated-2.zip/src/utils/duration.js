const ms = require('ms');

/**
 * Parse a duration string into milliseconds.
 * Supports: 1s, 5m, 2h, 1d, 1w, 1mo (approx 30d), 1y
 */
function parseDuration(str) {
  if (!str) return null;
  const cleaned = String(str).trim().toLowerCase();
  // ms library supports most common formats
  const value = ms(cleaned);
  if (value === undefined || isNaN(value) || value <= 0) {
    // Try manual common aliases
    const match = cleaned.match(/^(\d+)\s*(s|sec|secs|second|seconds|m|min|mins|minute|minutes|h|hr|hrs|hour|hours|d|day|days|w|week|weeks|mo|month|months|y|year|years)$/i);
    if (match) {
      const num = parseInt(match[1], 10);
      const unit = match[2].toLowerCase();
      const multipliers = {
        s: 1000, sec: 1000, secs: 1000, second: 1000, seconds: 1000,
        m: 60000, min: 60000, mins: 60000, minute: 60000, minutes: 60000,
        h: 3600000, hr: 3600000, hrs: 3600000, hour: 3600000, hours: 3600000,
        d: 86400000, day: 86400000, days: 86400000,
        w: 604800000, week: 604800000, weeks: 604800000,
        mo: 2592000000, month: 2592000000, months: 2592000000,
        y: 31536000000, year: 31536000000, years: 31536000000,
      };
      return num * (multipliers[unit] || 0) || null;
    }
    return null;
  }
  return value;
}

function formatDuration(msValue) {
  if (!msValue || msValue <= 0) return 'permanent';
  return ms(msValue, { long: true });
}

module.exports = { parseDuration, formatDuration };
