const { getStorage } = require('../storage');

/**
 * Periodically check for expired tempbans, mutes, and temp roles.
 * Called every 60 seconds from the main client.
 */
async function checkExpired(client) {
  const storage = getStorage();

  // Tempbans
  try {
    const expiredBans = await storage.getExpiredCases('tempban');
    for (const c of expiredBans) {
      try {
        const guild = await client.guilds.fetch(c.guildId).catch(() => null);
        if (guild) {
          await guild.members.unban(c.userId, 'Temporary ban expired').catch(() => {});
        }
        await storage.deactivateCase(c.guildId, c.caseId);
        console.log(`[Expiry] Unbanned ${c.userId} in ${c.guildId} (case #${c.caseId})`);
      } catch (err) {
        console.error(`[Expiry] Failed tempban cleanup for case #${c.caseId}:`, err.message);
      }
    }
  } catch (err) {
    console.error('[Expiry] tempban check error:', err.message);
  }

  // Mutes (Discord timeouts auto-expire, but we still mark our record inactive)
  try {
    const expiredMutes = await storage.getExpiredCases('mute');
    for (const c of expiredMutes) {
      try {
        await storage.deactivateCase(c.guildId, c.caseId);
        const guild = await client.guilds.fetch(c.guildId).catch(() => null);
        if (guild) {
          const member = await guild.members.fetch(c.userId).catch(() => null);
          if (member && member.communicationDisabledUntilTimestamp) {
            await member.timeout(null, 'Mute expired').catch(() => {});
          }
        }
        console.log(`[Expiry] Cleared mute for ${c.userId} (case #${c.caseId})`);
      } catch (err) {
        console.error(`[Expiry] Failed mute cleanup for case #${c.caseId}:`, err.message);
      }
    }
  } catch (err) {
    console.error('[Expiry] mute check error:', err.message);
  }

  // Temporary roles
  try {
    const expiredRoles = await storage.getExpiredCases('temprole');
    for (const c of expiredRoles) {
      try {
        const roleId = c.extra?.roleId;
        const guild = await client.guilds.fetch(c.guildId).catch(() => null);
        if (guild && roleId) {
          const member = await guild.members.fetch(c.userId).catch(() => null);
          if (member && member.roles.cache.has(roleId)) {
            await member.roles.remove(roleId, 'Temporary role expired').catch(() => {});
          }
        }
        await storage.deactivateCase(c.guildId, c.caseId);
        console.log(`[Expiry] Removed temp role from ${c.userId} (case #${c.caseId})`);
      } catch (err) {
        console.error(`[Expiry] Failed temprole cleanup for case #${c.caseId}:`, err.message);
      }
    }
  } catch (err) {
    console.error('[Expiry] temprole check error:', err.message);
  }
}

module.exports = { checkExpired };
