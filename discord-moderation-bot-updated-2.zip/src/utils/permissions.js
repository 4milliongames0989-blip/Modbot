const config = require('../config');
const { getStorage } = require('../storage');

/**
 * Check if a member can run a command (or subcommand).
 * Owners always can. Otherwise check cmdpermit for the exact command
 * or the parent command. Also falls back to Administrator permission.
 *
 * commandKey examples: "ban", "ban.add", "warn.list", "cmdpermit"
 */
async function canRunCommand(member, commandKey) {
  if (!member || !member.guild) return false;

  // Bot owners always allowed
  if (config.ownerIds.includes(member.id)) return true;

  // Discord Administrator permission always allowed
  if (member.permissions.has('Administrator')) return true;

  const storage = getStorage();
  const guildId = member.guild.id;

  // Check exact key first, then parent (e.g. "ban.add" -> also check "ban")
  const keysToCheck = [commandKey];
  if (commandKey.includes('.')) {
    keysToCheck.push(commandKey.split('.')[0]);
  }

  for (const key of keysToCheck) {
    const permit = await storage.getCmdPermit(guildId, key);
    if (!permit || !permit.targets || permit.targets.length === 0) continue;

    for (const t of permit.targets) {
      if (t.type === 'user' && t.id === member.id) return true;
      if (t.type === 'role' && member.roles.cache.has(t.id)) return true;
    }
  }

  return false;
}

/**
 * Resolve a user or role mention / id from interaction option.
 */
function resolveTarget(option) {
  if (!option) return null;
  if (option.user) return { type: 'user', id: option.user.id, label: option.user.tag };
  if (option.role) return { type: 'role', id: option.role.id, label: option.role.name };
  // raw id
  const id = option.value || option;
  return { type: 'user', id: String(id), label: id };
}

module.exports = { canRunCommand, resolveTarget };
