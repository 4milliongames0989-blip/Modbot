const { EmbedBuilder } = require('discord.js');
const { formatDuration } = require('./duration');

/**
 * Send a DM to the punished user. Silently fails if DMs are closed.
 */
async function sendPunishmentDM(user, {
  type,
  reason,
  caseId,
  guildName,
  moderatorTag,
  duration = null,
  expiresAt = null,
}) {
  try {
    const embed = new EmbedBuilder()
      .setColor(typeColor(type))
      .setTitle(`You have been ${typeLabel(type)}`)
      .setDescription(`**Server:** ${guildName}`)
      .addFields(
        { name: 'Reason', value: reason || 'No reason provided', inline: false },
        { name: 'Case ID', value: `#${caseId}`, inline: true },
        { name: 'Moderator', value: moderatorTag || 'Unknown', inline: true },
      )
      .setTimestamp();

    if (duration) {
      embed.addFields({ name: 'Duration', value: formatDuration(duration), inline: true });
    }
    if (expiresAt) {
      embed.addFields({
        name: 'Expires',
        value: `<t:${Math.floor(new Date(expiresAt).getTime() / 1000)}:R>`,
        inline: true,
      });
    }

    await user.send({ embeds: [embed] });
    return true;
  } catch (err) {
    // User has DMs disabled or blocked the bot
    return false;
  }
}

function typeLabel(type) {
  const map = {
    ban: 'banned',
    warn: 'warned',
    kick: 'kicked',
    tempban: 'temporarily banned',
    softban: 'softbanned',
    mute: 'muted',
  };
  return map[type] || type;
}

function typeColor(type) {
  const map = {
    ban: 0xe74c3c,
    warn: 0xf1c40f,
    kick: 0xe67e22,
    tempban: 0xe67e22,
    softban: 0x9b59b6,
    mute: 0x3498db,
  };
  return map[type] || 0x95a5a6;
}

module.exports = { sendPunishmentDM };
