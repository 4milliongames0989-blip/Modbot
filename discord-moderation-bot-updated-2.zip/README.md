# Discord Moderation Bot (Node.js)

A full-featured moderation bot with bans, warnings, temporary bans, softbans, mutes, case history, and granular command permissions.

## Features

- **Ban** – `/ban add|remove|edit|list`
- **Warn** – `/warn add|edit|remove` + `/warns list|user`
- **Tempban** – `/tempban add|remove|edit|list` (auto-unbans on expiry)
- **Softban** – `/softban add|edit|remove|list` (ban + unban to purge messages)
- **Mute** – `/mute add|edit|remove|list` (uses Discord timeouts, max 28 days)
- **Cases** – `/cases <user> <case_id>` view any moderation case
- **Command Permissions** – `/cmdpermit add|remove|list`
  - Grant/revoke access for specific users **or** roles
  - Supports **multiple commands at once** (space/comma separated)
  - Supports parent commands (`ban`) and subcommands (`ban.add`)
- **DM on punishment** – every punish action DMs the user (silently fails if DMs closed)
- **Dual storage backends**:
  1. **MongoDB** (recommended for production)
  2. **Discord file storage** – bot uploads `modbot-data.json` to a private channel and keeps the latest version

All list commands paginate **50 entries per page**.

## Requirements

- Node.js 18+
- A Discord Application + Bot token
- (Optional) MongoDB instance

## Setup

1. **Clone / copy the folder** and install dependencies:

```bash
cd discord-moderation-bot
npm install
```

2. **Create a `.env` file** from the example:

```bash
cp .env.example .env
```

Edit `.env`:

```env
DISCORD_TOKEN=your_bot_token
CLIENT_ID=your_application_id
GUILD_ID=                    # leave empty for global commands, or set a test guild ID
STORAGE_TYPE=mongodb         # or "discord"
MONGODB_URI=mongodb://localhost:27017/modbot
DATA_CHANNEL_ID=             # required only when STORAGE_TYPE=discord
OWNER_IDS=123456789012345678 # your Discord user ID(s), comma-separated
```

3. **Invite the bot** with the following permissions:
   - Ban Members
   - Moderate Members (timeouts)
   - Manage Messages (optional)
   - View Channels
   - Send Messages
   - Embed Links
   - Attach Files (for Discord storage mode)
   - Use Application Commands

   Scopes: `bot` + `applications.commands`

4. **Deploy slash commands**:

```bash
npm run deploy
```

5. **Start the bot**:

```bash
npm start
```

## Storage modes

### MongoDB (`STORAGE_TYPE=mongodb`)
- Stores cases, counters and command permits in MongoDB.
- Best for multi-server or high-volume use.

### Discord file (`STORAGE_TYPE=discord`)
- The bot uploads a single `modbot-data.json` file to the channel specified by `DATA_CHANNEL_ID`.
- On every write the previous message is deleted and a new one is posted.
- Simple, no external database required. Good for single-server bots.
- Make sure the channel is private (only the bot + trusted admins).

## Command permission system

By default only **bot owners** (from `OWNER_IDS`) and members with the **Administrator** permission can run moderation commands.

Use `/cmdpermit` to grant finer control:

```
/cmdpermit add commands:ban.add,warn,mute.list user:@Moderator
/cmdpermit add commands:ban role:@Mods
/cmdpermit remove commands:ban.add user:@Moderator
/cmdpermit list
```

You can pass multiple commands at once (space or comma separated).  
Both parent keys (`ban`) and subcommand keys (`ban.add`) are supported – granting the parent grants all its subcommands for permission checks.

## Case system

Every punishment creates a sequential case ID per guild.  
Use `/cases @user 42` to inspect a specific case (reason, moderator, duration, status, etc.).

## Notes

- Tempbans and mutes are automatically cleaned up every 60 seconds when they expire.
- Softban deletes messages for the number of days you specify (0–7) then immediately unbans the user.
- Mute uses Discord’s native timeout (max 28 days).
- All list commands are ephemeral (only visible to the invoker).

## License

MIT
